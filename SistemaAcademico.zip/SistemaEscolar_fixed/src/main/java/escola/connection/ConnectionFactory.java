package escola.connection;

import java.io.InputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Gerencia a conexão com o banco SQLite embarcado.
 * O arquivo escola.db é sempre criado na mesma pasta do JAR (ou no
 * diretório de trabalho como fallback), garantindo persistência real.
 */
public class ConnectionFactory {

    private static final String DB_FILE = "escola.db";
    private static final String URL;

    static {
        // Resolve o caminho absoluto ao lado do JAR em execução
        String dbPath;
        try {
            Path jarDir = Paths.get(
                ConnectionFactory.class
                    .getProtectionDomain()
                    .getCodeSource()
                    .getLocation()
                    .toURI()
            ).getParent();
            dbPath = jarDir.resolve(DB_FILE).toAbsolutePath().toString();
        } catch (Exception e) {
            // Fallback: diretório de trabalho atual
            dbPath = Paths.get(DB_FILE).toAbsolutePath().toString();
        }
        URL = "jdbc:sqlite:" + dbPath;
        System.out.println("[ConnectionFactory] Banco de dados: " + dbPath);
    }

    private static Connection instance;

    private ConnectionFactory() {}

    public static synchronized Connection getConnection() throws SQLException {
        if (instance == null || instance.isClosed()) {
            instance = DriverManager.getConnection(URL);
            instance.setAutoCommit(true); // garante commit automático em cada operação
            try (Statement st = instance.createStatement()) {
                st.execute("PRAGMA foreign_keys = ON");
                st.execute("PRAGMA journal_mode = WAL");
                st.execute("PRAGMA synchronous = NORMAL"); // persiste no disco corretamente
            }
            initSchema(instance);
        }
        return instance;
    }

    /**
     * Lê sql/escola.sql do classpath e executa cada instrução,
     * criando tabelas e dados de exemplo caso ainda não existam.
     */
    private static void initSchema(Connection conn) {
        try {
            URL resource = ConnectionFactory.class
                    .getClassLoader()
                    .getResource("sql/escola.sql");
            if (resource == null) {
                System.err.println("[initSchema] escola.sql não encontrado no classpath!");
                return;
            }

            try (InputStream is = resource.openStream()) {
                String sql = new String(is.readAllBytes(), StandardCharsets.UTF_8);
                String[] statements = sql
                        .replaceAll("--[^\\n]*", "")
                        .split(";");
                try (Statement st = conn.createStatement()) {
                    for (String stmt : statements) {
                        String trimmed = stmt.trim();
                        if (!trimmed.isEmpty()) {
                            st.execute(trimmed);
                        }
                    }
                }
            }
            System.out.println("[initSchema] Schema inicializado com sucesso.");
        } catch (Exception e) {
            System.err.println("[initSchema] " + e.getMessage());
        }
    }

    public static synchronized void close() {
        try {
            if (instance != null && !instance.isClosed()) {
                instance.close();
                instance = null;
            }
        } catch (SQLException ignored) {}
    }
}
