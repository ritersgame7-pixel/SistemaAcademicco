package escola.model;

public class Falta {
    private int    id;
    private int    alunoId;
    private int    disciplinaId;
    private String semestre;
    private int    totalFaltas;
    private int    totalAulas;
    private double percentualFreq;

    // join
    private String nomeAluno;
    private String nomeDisciplina;
    private String rgm;

    public Falta() {}

    public int    getId()                         { return id; }
    public void   setId(int id)                   { this.id = id; }
    public int    getAlunoId()                    { return alunoId; }
    public void   setAlunoId(int v)               { this.alunoId = v; }
    public int    getDisciplinaId()               { return disciplinaId; }
    public void   setDisciplinaId(int v)          { this.disciplinaId = v; }
    public String getSemestre()                   { return semestre; }
    public void   setSemestre(String s)           { this.semestre = s; }
    public int    getTotalFaltas()                { return totalFaltas; }
    public void   setTotalFaltas(int v)           { this.totalFaltas = v; }
    public int    getTotalAulas()                 { return totalAulas; }
    public void   setTotalAulas(int v)            { this.totalAulas = v; }
    public double getPercentualFreq()             { return percentualFreq; }
    public void   setPercentualFreq(double v)     { this.percentualFreq = v; }
    public String getNomeAluno()                  { return nomeAluno; }
    public void   setNomeAluno(String s)          { this.nomeAluno = s; }
    public String getNomeDisciplina()             { return nomeDisciplina; }
    public void   setNomeDisciplina(String s)     { this.nomeDisciplina = s; }
    public String getRgm()                        { return rgm; }
    public void   setRgm(String s)                { this.rgm = s; }
}
