package escola.model;

public class Disciplina {
    private int    id;
    private String codigo;
    private String nome;
    private int    cargaHora;
    private String periodo;
    private String curso;

    public Disciplina() {}

    public Disciplina(int id, String codigo, String nome, int cargaHora, String periodo, String curso) {
        this.id        = id;
        this.codigo    = codigo;
        this.nome      = nome;
        this.cargaHora = cargaHora;
        this.periodo   = periodo;
        this.curso     = curso;
    }

    public int    getId()                       { return id; }
    public void   setId(int id)                 { this.id = id; }
    public String getCodigo()                   { return codigo; }
    public void   setCodigo(String codigo)      { this.codigo = codigo; }
    public String getNome()                     { return nome; }
    public void   setNome(String nome)          { this.nome = nome; }
    public int    getCargaHora()                { return cargaHora; }
    public void   setCargaHora(int c)           { this.cargaHora = c; }
    public String getPeriodo()                  { return periodo; }
    public void   setPeriodo(String p)          { this.periodo = p; }
    public String getCurso()                    { return curso; }
    public void   setCurso(String c)            { this.curso = c; }

    @Override
    public String toString() { return codigo + " - " + nome; }
}
