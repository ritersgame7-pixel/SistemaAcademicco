package escola.model;

import java.time.LocalDate;

public class Aluno {

    private int id;
    private String rgm;
    private String nome;
    private String cpf;
    private String celular;
    private String email;
    private LocalDate dataNasc;
    private String endereco;
    private String curso;
    private String periodo;
    private String status;

    public Aluno() {}

    public Aluno(int id, String rgm, String nome, String cpf, String celular,
                 String email, LocalDate dataNasc, String endereco,
                 String curso, String periodo, String status) {
        this.id       = id;
        this.rgm      = rgm;
        this.nome     = nome;
        this.cpf      = cpf;
        this.celular  = celular;
        this.email    = email;
        this.dataNasc = dataNasc;
        this.endereco = endereco;
        this.curso    = curso;
        this.periodo  = periodo;
        this.status   = status;
    }

    // ---- Getters & Setters ----
    public int getId()                      { return id; }
    public void setId(int id)               { this.id = id; }

    public String getRgm()                  { return rgm; }
    public void setRgm(String rgm)          { this.rgm = rgm; }

    public String getNome()                 { return nome; }
    public void setNome(String nome)        { this.nome = nome; }

    public String getCpf()                  { return cpf; }
    public void setCpf(String cpf)          { this.cpf = cpf; }

    public String getCelular()              { return celular; }
    public void setCelular(String celular)  { this.celular = celular; }

    public String getEmail()                { return email; }
    public void setEmail(String email)      { this.email = email; }

    public LocalDate getDataNasc()                   { return dataNasc; }
    public void setDataNasc(LocalDate dataNasc)      { this.dataNasc = dataNasc; }

    public String getEndereco()                      { return endereco; }
    public void setEndereco(String endereco)         { this.endereco = endereco; }

    public String getCurso()                         { return curso; }
    public void setCurso(String curso)               { this.curso = curso; }

    public String getPeriodo()                       { return periodo; }
    public void setPeriodo(String periodo)           { this.periodo = periodo; }

    public String getStatus()                        { return status; }
    public void setStatus(String status)             { this.status = status; }

    @Override
    public String toString() { return nome + " (" + rgm + ")"; }
}
