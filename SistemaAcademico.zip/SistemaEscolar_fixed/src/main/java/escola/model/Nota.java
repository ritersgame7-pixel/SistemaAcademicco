package escola.model;

public class Nota {
    private int    id;
    private int    alunoId;
    private int    disciplinaId;
    private String semestre;
    private double av1;
    private double av2;
    private double av3;
    private double av4;
    private double notaFinal;
    private double media;
    private String situacao;

    // Extra (join)
    private String nomeAluno;
    private String nomeDisciplina;
    private String rgm;

    public Nota() {}

    // Getters & Setters
    public int    getId()                        { return id; }
    public void   setId(int id)                  { this.id = id; }
    public int    getAlunoId()                   { return alunoId; }
    public void   setAlunoId(int v)              { this.alunoId = v; }
    public int    getDisciplinaId()              { return disciplinaId; }
    public void   setDisciplinaId(int v)         { this.disciplinaId = v; }
    public String getSemestre()                  { return semestre; }
    public void   setSemestre(String s)          { this.semestre = s; }
    public double getAv1()                       { return av1; }
    public void   setAv1(double v)               { this.av1 = v; }
    public double getAv2()                       { return av2; }
    public void   setAv2(double v)               { this.av2 = v; }
    public double getAv3()                       { return av3; }
    public void   setAv3(double v)               { this.av3 = v; }
    public double getAv4()                       { return av4; }
    public void   setAv4(double v)               { this.av4 = v; }
    public double getNotaFinal()                 { return notaFinal; }
    public void   setNotaFinal(double v)         { this.notaFinal = v; }
    public double getMedia()                     { return media; }
    public void   setMedia(double v)             { this.media = v; }
    public String getSituacao()                  { return situacao; }
    public void   setSituacao(String s)          { this.situacao = s; }
    public String getNomeAluno()                 { return nomeAluno; }
    public void   setNomeAluno(String s)         { this.nomeAluno = s; }
    public String getNomeDisciplina()            { return nomeDisciplina; }
    public void   setNomeDisciplina(String s)    { this.nomeDisciplina = s; }
    public String getRgm()                       { return rgm; }
    public void   setRgm(String s)               { this.rgm = s; }
}
