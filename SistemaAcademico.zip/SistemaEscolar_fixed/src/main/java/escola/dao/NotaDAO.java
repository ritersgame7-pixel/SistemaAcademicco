package escola.dao;

import escola.connection.ConnectionFactory;
import escola.model.Nota;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NotaDAO {

    public void salvar(Nota n) throws SQLException {
        if (n.getId() == 0) inserir(n); else atualizar(n);
    }

    private void inserir(Nota n) throws SQLException {
        double media = Math.round(((n.getAv1() + n.getAv2() + n.getAv3() + n.getAv4()) / 4.0) * 100.0) / 100.0;
        n.setMedia(media);
        String sql = "INSERT INTO notas (aluno_id,disciplina_id,semestre,nota_av1,nota_av2,nota_av3,nota_av4,nota_final,media,situacao)"
                   + " VALUES (?,?,?,?,?,?,?,?,?,?)";
        try (PreparedStatement ps = ConnectionFactory.getConnection().prepareStatement(sql)) {
            ps.setInt   (1, n.getAlunoId());
            ps.setInt   (2, n.getDisciplinaId());
            ps.setString(3, n.getSemestre());
            ps.setDouble(4, n.getAv1());
            ps.setDouble(5, n.getAv2());
            ps.setDouble(6, n.getAv3());
            ps.setDouble(7, n.getAv4());
            ps.setDouble(8, n.getNotaFinal());
            ps.setDouble(9, media);
            ps.setString(10, n.getSituacao());
            ps.executeUpdate();
        }
    }

    private void atualizar(Nota n) throws SQLException {
        double media = Math.round(((n.getAv1() + n.getAv2() + n.getAv3() + n.getAv4()) / 4.0) * 100.0) / 100.0;
        n.setMedia(media);
        String sql = "UPDATE notas SET nota_av1=?,nota_av2=?,nota_av3=?,nota_av4=?,nota_final=?,media=?,situacao=? WHERE id=?";
        try (PreparedStatement ps = ConnectionFactory.getConnection().prepareStatement(sql)) {
            ps.setDouble(1, n.getAv1());
            ps.setDouble(2, n.getAv2());
            ps.setDouble(3, n.getAv3());
            ps.setDouble(4, n.getAv4());
            ps.setDouble(5, n.getNotaFinal());
            ps.setDouble(6, media);
            ps.setString(7, n.getSituacao());
            ps.setInt   (8, n.getId());
            ps.executeUpdate();
        }
    }

    public void excluir(int id) throws SQLException {
        try (PreparedStatement ps = ConnectionFactory.getConnection()
                .prepareStatement("DELETE FROM notas WHERE id=?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public List<Nota> listarPorAluno(int alunoId) throws SQLException {
        List<Nota> lista = new ArrayList<>();
        String sql = "SELECT n.*, a.nome AS nome_aluno, a.rgm, d.nome AS nome_disc "
                   + "FROM notas n "
                   + "JOIN alunos a ON a.id = n.aluno_id "
                   + "JOIN disciplinas d ON d.id = n.disciplina_id "
                   + "WHERE n.aluno_id=? ORDER BY n.semestre, d.nome";
        try (PreparedStatement ps = ConnectionFactory.getConnection().prepareStatement(sql)) {
            ps.setInt(1, alunoId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) lista.add(mapear(rs));
            }
        }
        return lista;
    }

    public List<Nota> listarTodas() throws SQLException {
        List<Nota> lista = new ArrayList<>();
        String sql = "SELECT n.*, a.nome AS nome_aluno, a.rgm, d.nome AS nome_disc "
                   + "FROM notas n "
                   + "JOIN alunos a ON a.id = n.aluno_id "
                   + "JOIN disciplinas d ON d.id = n.disciplina_id "
                   + "ORDER BY a.nome, n.semestre";
        try (Statement st = ConnectionFactory.getConnection().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) lista.add(mapear(rs));
        }
        return lista;
    }

    public Nota buscarPorAlunoDiscSemestre(int alunoId, int discId, String semestre) throws SQLException {
        String sql = "SELECT n.*, a.nome AS nome_aluno, a.rgm, d.nome AS nome_disc "
                   + "FROM notas n "
                   + "JOIN alunos a ON a.id=n.aluno_id "
                   + "JOIN disciplinas d ON d.id=n.disciplina_id "
                   + "WHERE n.aluno_id=? AND n.disciplina_id=? AND n.semestre=?";
        try (PreparedStatement ps = ConnectionFactory.getConnection().prepareStatement(sql)) {
            ps.setInt   (1, alunoId);
            ps.setInt   (2, discId);
            ps.setString(3, semestre);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapear(rs);
            }
        }
        return null;
    }

    private Nota mapear(ResultSet rs) throws SQLException {
        Nota n = new Nota();
        n.setId            (rs.getInt("id"));
        n.setAlunoId       (rs.getInt("aluno_id"));
        n.setDisciplinaId  (rs.getInt("disciplina_id"));
        n.setSemestre      (rs.getString("semestre"));
        n.setAv1           (rs.getDouble("nota_av1"));
        n.setAv2           (rs.getDouble("nota_av2"));
        n.setAv3           (rs.getDouble("nota_av3"));
        n.setAv4           (rs.getDouble("nota_av4"));
        n.setNotaFinal     (rs.getDouble("nota_final"));
        n.setMedia         (rs.getDouble("media"));
        n.setSituacao      (rs.getString("situacao"));
        n.setNomeAluno     (rs.getString("nome_aluno"));
        n.setNomeDisciplina(rs.getString("nome_disc"));
        n.setRgm           (rs.getString("rgm"));
        return n;
    }
}
