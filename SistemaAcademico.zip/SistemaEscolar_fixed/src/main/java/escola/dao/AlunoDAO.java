package escola.dao;

import escola.connection.ConnectionFactory;
import escola.model.Aluno;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class AlunoDAO {

    // ── INSERT ──────────────────────────────────────────────────────────────
    public void inserir(Aluno a) throws SQLException {
        String sql = "INSERT INTO alunos (rgm,nome,cpf,celular,email,data_nasc,endereco,curso,periodo,status) "
                   + "VALUES (?,?,?,?,?,?,?,?,?,?)";
        try (PreparedStatement ps = ConnectionFactory.getConnection().prepareStatement(sql)) {
            ps.setString(1, a.getRgm());
            ps.setString(2, a.getNome());
            ps.setString(3, a.getCpf());
            ps.setString(4, a.getCelular());
            ps.setString(5, a.getEmail());
            ps.setString(6, a.getDataNasc() != null ? a.getDataNasc().toString() : null);
            ps.setString(7, a.getEndereco());
            ps.setString(8, a.getCurso());
            ps.setString(9, a.getPeriodo());
            ps.setString(10, a.getStatus());
            ps.executeUpdate();
            // autoCommit=true: commit já ocorre automaticamente. Nenhum commit manual necessário.
        }
    }

    // ── UPDATE ──────────────────────────────────────────────────────────────
    public void atualizar(Aluno a) throws SQLException {
        String sql = "UPDATE alunos SET nome=?,cpf=?,celular=?,email=?,data_nasc=?,"
                   + "endereco=?,curso=?,periodo=?,status=? WHERE id=?";
        try (PreparedStatement ps = ConnectionFactory.getConnection().prepareStatement(sql)) {
            ps.setString(1, a.getNome());
            ps.setString(2, a.getCpf());
            ps.setString(3, a.getCelular());
            ps.setString(4, a.getEmail());
            ps.setString(5, a.getDataNasc() != null ? a.getDataNasc().toString() : null);
            ps.setString(6, a.getEndereco());
            ps.setString(7, a.getCurso());
            ps.setString(8, a.getPeriodo());
            ps.setString(9, a.getStatus());
            ps.setInt   (10, a.getId());
            ps.executeUpdate();
            // autoCommit=true: commit já ocorre automaticamente. Nenhum commit manual necessário.
        }
    }

    // ── DELETE (cascade apaga notas e faltas via FK) ────────────────────────
    public void excluir(int id) throws SQLException {
        String sql = "DELETE FROM alunos WHERE id=?";
        try (PreparedStatement ps = ConnectionFactory.getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
            // autoCommit=true: commit já ocorre automaticamente. Nenhum commit manual necessário.
        }
    }

    // ── SELECT ALL ──────────────────────────────────────────────────────────
    public List<Aluno> listarTodos() throws SQLException {
        List<Aluno> lista = new ArrayList<>();
        String sql = "SELECT * FROM alunos ORDER BY nome";
        try (Statement st = ConnectionFactory.getConnection().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) lista.add(mapear(rs));
        }
        return lista;
    }

    // ── BUSCA POR RGM ────────────────────────────────────────────────────────
    public Aluno buscarPorRgm(String rgm) throws SQLException {
        String sql = "SELECT * FROM alunos WHERE rgm=?";
        try (PreparedStatement ps = ConnectionFactory.getConnection().prepareStatement(sql)) {
            ps.setString(1, rgm);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapear(rs);
            }
        }
        return null;
    }

    // ── BUSCA POR NOME (LIKE) ────────────────────────────────────────────────
    public List<Aluno> buscarPorNome(String nome) throws SQLException {
        List<Aluno> lista = new ArrayList<>();
        String sql = "SELECT * FROM alunos WHERE nome LIKE ? ORDER BY nome";
        try (PreparedStatement ps = ConnectionFactory.getConnection().prepareStatement(sql)) {
            ps.setString(1, "%" + nome + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) lista.add(mapear(rs));
            }
        }
        return lista;
    }

    // ── BUSCA POR ID ─────────────────────────────────────────────────────────
    public Aluno buscarPorId(int id) throws SQLException {
        String sql = "SELECT * FROM alunos WHERE id=?";
        try (PreparedStatement ps = ConnectionFactory.getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapear(rs);
            }
        }
        return null;
    }

    // ── VERIFICA DUPLICIDADE DE RGM ──────────────────────────────────────────
    public boolean rgmExiste(String rgm, int ignorarId) throws SQLException {
        String sql = "SELECT id FROM alunos WHERE rgm=? AND id<>?";
        try (PreparedStatement ps = ConnectionFactory.getConnection().prepareStatement(sql)) {
            ps.setString(1, rgm);
            ps.setInt   (2, ignorarId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    // ── MAPPER ───────────────────────────────────────────────────────────────
    private Aluno mapear(ResultSet rs) throws SQLException {
        Aluno a = new Aluno();
        a.setId       (rs.getInt("id"));
        a.setRgm      (rs.getString("rgm"));
        a.setNome     (rs.getString("nome"));
        a.setCpf      (rs.getString("cpf"));
        a.setCelular  (rs.getString("celular"));
        a.setEmail    (rs.getString("email"));
        String dataNasc = rs.getString("data_nasc");
        if (dataNasc != null && !dataNasc.isEmpty()) a.setDataNasc(LocalDate.parse(dataNasc));
        a.setEndereco (rs.getString("endereco"));
        a.setCurso    (rs.getString("curso"));
        a.setPeriodo  (rs.getString("periodo"));
        a.setStatus   (rs.getString("status"));
        return a;
    }
}
