package escola.dao;

import escola.connection.ConnectionFactory;
import escola.model.Falta;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FaltaDAO {

    public void salvar(Falta f) throws SQLException {
        if (f.getId() == 0) inserir(f); else atualizar(f);
    }

    private void inserir(Falta f) throws SQLException {
        double perc = f.getTotalAulas() > 0
            ? Math.round(((f.getTotalAulas() - f.getTotalFaltas()) / (double) f.getTotalAulas()) * 10000.0) / 100.0
            : 0.0;
        f.setPercentualFreq(perc);
        String sql = "INSERT INTO faltas (aluno_id,disciplina_id,semestre,total_faltas,total_aulas,percentual_freq) VALUES (?,?,?,?,?,?)";
        try (PreparedStatement ps = ConnectionFactory.getConnection().prepareStatement(sql)) {
            ps.setInt   (1, f.getAlunoId());
            ps.setInt   (2, f.getDisciplinaId());
            ps.setString(3, f.getSemestre());
            ps.setInt   (4, f.getTotalFaltas());
            ps.setInt   (5, f.getTotalAulas());
            ps.setDouble(6, perc);
            ps.executeUpdate();
        }
    }

    private void atualizar(Falta f) throws SQLException {
        double perc = f.getTotalAulas() > 0
            ? Math.round(((f.getTotalAulas() - f.getTotalFaltas()) / (double) f.getTotalAulas()) * 10000.0) / 100.0
            : 0.0;
        f.setPercentualFreq(perc);
        String sql = "UPDATE faltas SET total_faltas=?,total_aulas=?,percentual_freq=? WHERE id=?";
        try (PreparedStatement ps = ConnectionFactory.getConnection().prepareStatement(sql)) {
            ps.setInt   (1, f.getTotalFaltas());
            ps.setInt   (2, f.getTotalAulas());
            ps.setDouble(3, perc);
            ps.setInt   (4, f.getId());
            ps.executeUpdate();
        }
    }

    public void excluir(int id) throws SQLException {
        try (PreparedStatement ps = ConnectionFactory.getConnection()
                .prepareStatement("DELETE FROM faltas WHERE id=?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public List<Falta> listarPorAluno(int alunoId) throws SQLException {
        List<Falta> lista = new ArrayList<>();
        String sql = "SELECT f.*, a.nome AS nome_aluno, a.rgm, d.nome AS nome_disc, d.carga_hora "
                   + "FROM faltas f "
                   + "JOIN alunos a ON a.id=f.aluno_id "
                   + "JOIN disciplinas d ON d.id=f.disciplina_id "
                   + "WHERE f.aluno_id=? ORDER BY f.semestre, d.nome";
        try (PreparedStatement ps = ConnectionFactory.getConnection().prepareStatement(sql)) {
            ps.setInt(1, alunoId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) lista.add(mapear(rs));
            }
        }
        return lista;
    }

    public List<Falta> listarTodas() throws SQLException {
        List<Falta> lista = new ArrayList<>();
        String sql = "SELECT f.*, a.nome AS nome_aluno, a.rgm, d.nome AS nome_disc, d.carga_hora "
                   + "FROM faltas f "
                   + "JOIN alunos a ON a.id=f.aluno_id "
                   + "JOIN disciplinas d ON d.id=f.disciplina_id "
                   + "ORDER BY a.nome, f.semestre";
        try (Statement st = ConnectionFactory.getConnection().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) lista.add(mapear(rs));
        }
        return lista;
    }

    public Falta buscarPorAlunoDiscSemestre(int alunoId, int discId, String semestre) throws SQLException {
        String sql = "SELECT f.*, a.nome AS nome_aluno, a.rgm, d.nome AS nome_disc, d.carga_hora "
                   + "FROM faltas f "
                   + "JOIN alunos a ON a.id=f.aluno_id "
                   + "JOIN disciplinas d ON d.id=f.disciplina_id "
                   + "WHERE f.aluno_id=? AND f.disciplina_id=? AND f.semestre=?";
        try (PreparedStatement ps = ConnectionFactory.getConnection().prepareStatement(sql)) {
            ps.setInt   (1, alunoId);
            ps.setInt   (2, discId);
            ps.setString(3, semestre);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapear(rs);
            }
        }
        return null;
    }

    private Falta mapear(ResultSet rs) throws SQLException {
        Falta f = new Falta();
        f.setId            (rs.getInt("id"));
        f.setAlunoId       (rs.getInt("aluno_id"));
        f.setDisciplinaId  (rs.getInt("disciplina_id"));
        f.setSemestre      (rs.getString("semestre"));
        f.setTotalFaltas   (rs.getInt("total_faltas"));
        f.setTotalAulas    (rs.getInt("total_aulas"));
        f.setPercentualFreq(rs.getDouble("percentual_freq"));
        f.setNomeAluno     (rs.getString("nome_aluno"));
        f.setNomeDisciplina(rs.getString("nome_disc"));
        f.setRgm           (rs.getString("rgm"));
        return f;
    }
}
