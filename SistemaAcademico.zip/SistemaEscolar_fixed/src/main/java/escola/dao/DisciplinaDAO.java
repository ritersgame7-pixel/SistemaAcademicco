package escola.dao;

import escola.connection.ConnectionFactory;
import escola.model.Disciplina;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DisciplinaDAO {

    public void inserir(Disciplina d) throws SQLException {
        String sql = "INSERT INTO disciplinas (codigo,nome,carga_hora,periodo,curso) VALUES (?,?,?,?,?)";
        try (PreparedStatement ps = ConnectionFactory.getConnection().prepareStatement(sql)) {
            ps.setString(1, d.getCodigo());
            ps.setString(2, d.getNome());
            ps.setInt   (3, d.getCargaHora());
            ps.setString(4, d.getPeriodo());
            ps.setString(5, d.getCurso());
            ps.executeUpdate();
        }
    }

    public void atualizar(Disciplina d) throws SQLException {
        String sql = "UPDATE disciplinas SET codigo=?,nome=?,carga_hora=?,periodo=?,curso=? WHERE id=?";
        try (PreparedStatement ps = ConnectionFactory.getConnection().prepareStatement(sql)) {
            ps.setString(1, d.getCodigo());
            ps.setString(2, d.getNome());
            ps.setInt   (3, d.getCargaHora());
            ps.setString(4, d.getPeriodo());
            ps.setString(5, d.getCurso());
            ps.setInt   (6, d.getId());
            ps.executeUpdate();
        }
    }

    public void excluir(int id) throws SQLException {
        try (PreparedStatement ps = ConnectionFactory.getConnection()
                .prepareStatement("DELETE FROM disciplinas WHERE id=?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public List<Disciplina> listarTodas() throws SQLException {
        List<Disciplina> lista = new ArrayList<>();
        try (Statement st = ConnectionFactory.getConnection().createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM disciplinas ORDER BY nome")) {
            while (rs.next()) lista.add(mapear(rs));
        }
        return lista;
    }

    public Disciplina buscarPorId(int id) throws SQLException {
        try (PreparedStatement ps = ConnectionFactory.getConnection()
                .prepareStatement("SELECT * FROM disciplinas WHERE id=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapear(rs);
            }
        }
        return null;
    }

    private Disciplina mapear(ResultSet rs) throws SQLException {
        Disciplina d = new Disciplina();
        d.setId       (rs.getInt("id"));
        d.setCodigo   (rs.getString("codigo"));
        d.setNome     (rs.getString("nome"));
        d.setCargaHora(rs.getInt("carga_hora"));
        d.setPeriodo  (rs.getString("periodo"));
        d.setCurso    (rs.getString("curso"));
        return d;
    }
}
