package escola.util;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Botão estilizado com efeito hover.
 */
public class StyledButton extends JButton {

    private final Color baseColor;
    private final Color hoverColor;

    public StyledButton(String text, Color baseColor) {
        super(text);
        this.baseColor  = baseColor;
        this.hoverColor = baseColor.darker();

        setFont(UITheme.FONT_BTN);
        setForeground(Color.WHITE);
        setBackground(baseColor);
        setFocusPainted(false);
        setBorderPainted(false);
        setOpaque(true);
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        setPreferredSize(new Dimension(130, 34));

        addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { setBackground(hoverColor); }
            @Override public void mouseExited (MouseEvent e) { setBackground(baseColor); }
        });
    }

    /** Atalho: cria botão primário */
    public static StyledButton primary(String text) {
        return new StyledButton(text, UITheme.PRIMARY);
    }

    /** Atalho: cria botão de sucesso (verde) */
    public static StyledButton success(String text) {
        return new StyledButton(text, UITheme.SUCCESS);
    }

    /** Atalho: cria botão de perigo (vermelho) */
    public static StyledButton danger(String text) {
        return new StyledButton(text, UITheme.DANGER);
    }

    /** Atalho: cria botão de aviso (laranja) */
    public static StyledButton warning(String text) {
        return new StyledButton(text, UITheme.ACCENT);
    }
}
