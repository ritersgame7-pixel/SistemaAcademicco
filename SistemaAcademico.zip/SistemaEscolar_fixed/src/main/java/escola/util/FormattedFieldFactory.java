package escola.util;

import javax.swing.*;
import javax.swing.text.MaskFormatter;
import java.text.ParseException;

/**
 * Fábrica de JFormattedTextField com máscara.
 */
public class FormattedFieldFactory {

    public static JFormattedTextField createCpfField() {
        return createMaskedField("###.###.###-##");
    }

    public static JFormattedTextField createCelularField() {
        return createMaskedField("(##) #####-####");
    }

    public static JFormattedTextField createDateField() {
        return createMaskedField("##/##/####");
    }

    private static JFormattedTextField createMaskedField(String mask) {
        try {
            MaskFormatter mf = new MaskFormatter(mask);
            mf.setPlaceholderCharacter('_');
            JFormattedTextField field = new JFormattedTextField(mf);
            field.setColumns(15);
            return field;
        } catch (ParseException e) {
            return new JFormattedTextField();
        }
    }
}
