package escola.util;

import java.awt.*;

/**
 * Paleta de cores e fontes centralizada.
 */
public class UITheme {

    // ── Cores ──────────────────────────────────────────────────────────────
    public static final Color PRIMARY       = new Color(0x1A3A5C);   // azul escuro
    public static final Color SECONDARY     = new Color(0x2E7D9E);   // azul médio
    public static final Color ACCENT        = new Color(0xE8A020);   // âmbar
    public static final Color BG_PANEL      = new Color(0xF4F6F9);   // cinza muito claro
    public static final Color BG_CARD       = Color.WHITE;
    public static final Color TEXT_DARK     = new Color(0x1C1C2E);
    public static final Color TEXT_MUTED    = new Color(0x7A8599);
    public static final Color SUCCESS       = new Color(0x27AE60);
    public static final Color DANGER        = new Color(0xE74C3C);
    public static final Color WARNING       = new Color(0xF39C12);
    public static final Color BORDER        = new Color(0xDDE3ED);
    public static final Color TABLE_STRIPE  = new Color(0xF0F5FF);
    public static final Color TABLE_HEADER  = new Color(0x1A3A5C);

    // ── Fontes ────────────────────────────────────────────────────────────
    public static final Font FONT_TITLE     = new Font("Segoe UI", Font.BOLD,  20);
    public static final Font FONT_SUBTITLE  = new Font("Segoe UI", Font.BOLD,  14);
    public static final Font FONT_BODY      = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONT_SMALL     = new Font("Segoe UI", Font.PLAIN, 11);
    public static final Font FONT_LABEL     = new Font("Segoe UI", Font.BOLD,  12);
    public static final Font FONT_BTN       = new Font("Segoe UI", Font.BOLD,  13);

    private UITheme() {}
}
