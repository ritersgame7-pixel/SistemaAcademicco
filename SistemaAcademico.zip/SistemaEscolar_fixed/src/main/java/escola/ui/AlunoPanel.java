package escola.ui;

import escola.dao.AlunoDAO;
import escola.model.Aluno;
import escola.util.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import javax.swing.text.MaskFormatter;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

public class AlunoPanel extends JPanel {

    private final AlunoDAO dao = new AlunoDAO();
    private Aluno alunoEditando = null;

    // Campos do formulário
    private JTextField tfRgm, tfNome, tfEmail, tfEndereco;
    private JFormattedTextField tfCpf, tfCelular, tfDataNasc;
    private JComboBox<String> cbCurso, cbPeriodo, cbStatus;

    // Tabela
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField tfBusca;

    // Feedback
    private JLabel lblFeedback;

    // Tabs
    private JTabbedPane tabbedPane;

    public AlunoPanel() {
        setLayout(new BorderLayout());
        setBackground(UITheme.BG_PANEL);
        add(buildHeader(), BorderLayout.NORTH);
        tabbedPane = buildTabs();
        add(tabbedPane, BorderLayout.CENTER);
        carregarTabela(null);
    }

    // ── HEADER ───────────────────────────────────────────────────────────
    private JPanel buildHeader() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(UITheme.PRIMARY);
        p.setBorder(BorderFactory.createEmptyBorder(14, 20, 14, 20));
        JLabel lbl = new JLabel("👨‍🎓  Gerenciamento de Alunos");
        lbl.setFont(UITheme.FONT_TITLE);
        lbl.setForeground(Color.WHITE);
        p.add(lbl, BorderLayout.WEST);
        return p;
    }

    // ── TABS ─────────────────────────────────────────────────────────────
    private JTabbedPane buildTabs() {
        JTabbedPane tp = new JTabbedPane(JTabbedPane.TOP);
        tp.setFont(UITheme.FONT_SUBTITLE);
        tp.setBackground(UITheme.BG_PANEL);
        tp.addTab("📋  Cadastro", buildCadastroTab());
        tp.addTab("🔍  Listagem", buildListagemTab());
        return tp;
    }

    // ── CRIA CAMPO MASCARADO ─────────────────────────────────────────────
    private JFormattedTextField maskedField(String mask, String placeholder) {
        try {
            MaskFormatter mf = new MaskFormatter(mask);
            mf.setPlaceholderCharacter(placeholder.charAt(0));
            mf.setAllowsInvalid(false);
            mf.setCommitsOnValidEdit(true);
            JFormattedTextField f = new JFormattedTextField(mf);
            f.setFont(UITheme.FONT_BODY);
            f.setColumns(15);
            return f;
        } catch (ParseException e) {
            return new JFormattedTextField();
        }
    }

    // ── ABA CADASTRO ─────────────────────────────────────────────────────
    private JPanel buildCadastroTab() {
        JPanel root = new JPanel(new BorderLayout(0, 10));
        root.setBackground(UITheme.BG_PANEL);
        root.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(UITheme.BG_CARD);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER, 1, true),
                BorderFactory.createEmptyBorder(20, 24, 20, 24)));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 6, 4, 6);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill   = GridBagConstraints.HORIZONTAL;

        // Linha 0: RGM | Nome
        tfRgm  = new JTextField(12);
        tfNome = new JTextField(30);
        addField(card, gbc, "RGM *",           tfRgm,  0, 0);
        addField(card, gbc, "Nome Completo *",  tfNome, 2, 0);

        // Linha 1: CPF | Celular | Data Nasc
        // CPF: ###.###.###-## = 14 chars com máscara
        tfCpf     = maskedField("###.###.###-##", "_");
        // Celular: (##) #####-#### = 15 chars
        tfCelular = maskedField("(##) #####-####", "_");
        // Data: ##/##/#### = 10 chars — bloqueio de entrada garante formato correto
        tfDataNasc = maskedField("##/##/####", "_");
        tfDataNasc.setToolTipText("Digite: dd/mm/aaaa");

        addField(card, gbc, "CPF",                        tfCpf,     0, 1);
        addField(card, gbc, "Celular",                    tfCelular, 2, 1);
        addField(card, gbc, "Data de Nascimento * (dd/mm/aaaa)", tfDataNasc, 4, 1);

        // Linha 2: E-mail | Endereço
        tfEmail    = new JTextField(25);
        tfEndereco = new JTextField(40);
        addField(card, gbc, "E-mail", tfEmail, 0, 2);
        gbc.gridwidth = 3;
        addField(card, gbc, "Endereço", tfEndereco, 2, 2);
        gbc.gridwidth = 1;

        // Linha 3: Curso | Período | Status
        String[] cursos   = {"Ciência da Computação","Sistemas de Informação","Engenharia de Software",
                             "Análise e Desenvolvimento de Sistemas","Outros"};
        String[] periodos = {"1º","2º","3º","4º","5º","6º","7º","8º"};
        String[] statuses = {"Ativo","Inativo","Trancado"};
        cbCurso   = new JComboBox<>(cursos);
        cbPeriodo = new JComboBox<>(periodos);
        cbStatus  = new JComboBox<>(statuses);
        for (JComboBox<?> cb : new JComboBox[]{cbCurso, cbPeriodo, cbStatus})
            cb.setFont(UITheme.FONT_BODY);
        addField(card, gbc, "Curso *",   cbCurso,   0, 3);
        addField(card, gbc, "Período *", cbPeriodo, 2, 3);
        addField(card, gbc, "Status",    cbStatus,  4, 3);

        // ── FEEDBACK + BOTÕES ──
        JPanel bottomArea = new JPanel(new BorderLayout(0, 8));
        bottomArea.setOpaque(false);
        bottomArea.setBorder(BorderFactory.createEmptyBorder(12, 0, 0, 0));

        lblFeedback = new JLabel(" ", SwingConstants.CENTER);
        lblFeedback.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblFeedback.setOpaque(true);
        lblFeedback.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        lblFeedback.setBackground(UITheme.BG_PANEL);
        lblFeedback.setForeground(UITheme.BG_PANEL);

        // Botão principal
        JButton btnCadastrar = new JButton("✅   CADASTRAR ALUNO");
        btnCadastrar.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btnCadastrar.setBackground(new Color(0x1B6B2F));
        btnCadastrar.setForeground(Color.WHITE);
        btnCadastrar.setFocusPainted(false);
        btnCadastrar.setBorderPainted(false);
        btnCadastrar.setOpaque(true);
        btnCadastrar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnCadastrar.setPreferredSize(new Dimension(240, 44));
        btnCadastrar.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btnCadastrar.setBackground(new Color(0x145222)); }
            @Override public void mouseExited (MouseEvent e) { btnCadastrar.setBackground(new Color(0x1B6B2F)); }
        });
        btnCadastrar.addActionListener(e -> cadastrar());

        // Botões secundários
        JButton btnLimpar  = new JButton("🔄  Limpar");
        JButton btnExcluir = new JButton("🗑  Excluir");
        for (JButton b : new JButton[]{btnLimpar, btnExcluir}) {
            b.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            b.setFocusPainted(false);
            b.setBorderPainted(false);
            b.setOpaque(true);
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            b.setPreferredSize(new Dimension(130, 36));
        }
        btnLimpar.setBackground(new Color(0x1565C0));  btnLimpar.setForeground(Color.WHITE);
        btnExcluir.setBackground(new Color(0xC62828)); btnExcluir.setForeground(Color.WHITE);
        btnLimpar .addActionListener(e -> limparForm());
        btnExcluir.addActionListener(e -> excluir());

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        btnRow.setOpaque(false);
        btnRow.add(btnCadastrar);
        btnRow.add(btnLimpar);
        btnRow.add(btnExcluir);

        bottomArea.add(lblFeedback, BorderLayout.NORTH);
        bottomArea.add(btnRow,      BorderLayout.CENTER);

        JScrollPane scroll = new JScrollPane(card);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(UITheme.BG_PANEL);
        root.add(scroll,     BorderLayout.CENTER);
        root.add(bottomArea, BorderLayout.SOUTH);
        return root;
    }

    private void addField(JPanel panel, GridBagConstraints gbc,
                          String label, JComponent field, int col, int row) {
        JLabel lbl = new JLabel(label);
        lbl.setFont(UITheme.FONT_LABEL);
        lbl.setForeground(UITheme.TEXT_DARK);
        gbc.gridx = col; gbc.gridy = row * 2;
        panel.add(lbl, gbc);
        if (field instanceof JTextField tf && !(field instanceof JFormattedTextField))
            tf.setFont(UITheme.FONT_BODY);
        gbc.gridx = col; gbc.gridy = row * 2 + 1;
        panel.add(field, gbc);
    }

    // ── ABA LISTAGEM ─────────────────────────────────────────────────────
    private JPanel buildListagemTab() {
        JPanel root = new JPanel(new BorderLayout(0, 8));
        root.setBackground(UITheme.BG_PANEL);
        root.setBorder(BorderFactory.createEmptyBorder(12, 15, 12, 15));

        JPanel busca = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        busca.setOpaque(false);
        tfBusca = new JTextField(25);
        tfBusca.setFont(UITheme.FONT_BODY);
        StyledButton btnBuscar    = StyledButton.primary("🔍  Buscar");
        StyledButton btnAtualizar = StyledButton.warning("↻  Todos");
        StyledButton btnEditar    = StyledButton.primary("✏  Editar");
        btnBuscar   .addActionListener(e -> carregarTabela(tfBusca.getText().trim()));
        btnAtualizar.addActionListener(e -> { tfBusca.setText(""); carregarTabela(null); });
        btnEditar   .addActionListener(e -> carregarParaEditar());
        busca.add(new JLabel("Busca:")); busca.add(tfBusca);
        busca.add(btnBuscar); busca.add(btnAtualizar);
        busca.add(Box.createHorizontalStrut(20)); busca.add(btnEditar);

        String[] cols = {"ID","RGM","Nome","CPF","Celular","Curso","Período","Status"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        estilizarTabela(table);

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(UITheme.BORDER));
        root.add(busca,  BorderLayout.NORTH);
        root.add(scroll, BorderLayout.CENTER);
        return root;
    }

    private void estilizarTabela(JTable t) {
        t.setFont(UITheme.FONT_BODY);
        t.setRowHeight(28);
        t.setGridColor(UITheme.BORDER);
        t.setShowHorizontalLines(true);
        t.setShowVerticalLines(false);
        t.setSelectionBackground(new Color(0xBDD5E8));
        t.setSelectionForeground(UITheme.TEXT_DARK);
        JTableHeader h = t.getTableHeader();
        h.setFont(UITheme.FONT_LABEL);
        h.setBackground(UITheme.TABLE_HEADER);
        h.setForeground(Color.WHITE);
        h.setReorderingAllowed(false);
        t.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable tbl, Object v,
                    boolean isSel, boolean hasFocus, int row, int col) {
                super.getTableCellRendererComponent(tbl, v, isSel, hasFocus, row, col);
                if (!isSel) setBackground(row % 2 == 0 ? Color.WHITE : UITheme.TABLE_STRIPE);
                setBorder(BorderFactory.createEmptyBorder(0, 6, 0, 6));
                return this;
            }
        });
        t.getColumnModel().getColumn(0).setMinWidth(0);
        t.getColumnModel().getColumn(0).setMaxWidth(0);
        t.getColumnModel().getColumn(0).setWidth(0);
    }

    // ── LÓGICA ───────────────────────────────────────────────────────────

    private void mostrarFeedback(boolean sucesso, String msg) {
        lblFeedback.setText(msg);
        lblFeedback.setBackground(sucesso ? new Color(0xD4EDDA) : new Color(0xF8D7DA));
        lblFeedback.setForeground(sucesso ? new Color(0x155724) : new Color(0x721C24));
        new javax.swing.Timer(5000, ev -> {
            lblFeedback.setText(" ");
            lblFeedback.setBackground(UITheme.BG_PANEL);
            lblFeedback.setForeground(UITheme.BG_PANEL);
            ((javax.swing.Timer) ev.getSource()).stop();
        }).start();
    }

    private void marcarErro(JComponent campo) {
        campo.setBorder(BorderFactory.createLineBorder(Color.RED, 2));
        // Remove borda de erro após 3s
        new javax.swing.Timer(3000, ev -> {
            campo.setBorder(UIManager.getBorder("TextField.border"));
            ((javax.swing.Timer) ev.getSource()).stop();
        }).start();
    }

    private void cadastrar() {
        // 1. RGM obrigatório
        if (tfRgm.getText().isBlank()) {
            mostrarFeedback(false, "❌  RGM é obrigatório.");
            marcarErro(tfRgm); tfRgm.requestFocus(); return;
        }

        // 2. Nome obrigatório
        if (tfNome.getText().isBlank()) {
            mostrarFeedback(false, "❌  Nome Completo é obrigatório.");
            marcarErro(tfNome); tfNome.requestFocus(); return;
        }

        // 3. Data obrigatória e no formato correto
        // O MaskFormatter garante que só entram dígitos e / mas os _ indicam incompleto
        String rawData = tfDataNasc.getText();
        if (rawData == null || rawData.contains("_") || rawData.isBlank()) {
            mostrarFeedback(false, "❌  Data de Nascimento é obrigatória. Use: dd/mm/aaaa");
            marcarErro(tfDataNasc); tfDataNasc.requestFocus(); return;
        }
        LocalDate dataNasc;
        try {
            dataNasc = LocalDate.parse(rawData.trim(), DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        } catch (DateTimeParseException ex) {
            mostrarFeedback(false, "❌  Data inválida. Use: dd/mm/aaaa  (ex: 15/03/2002)");
            marcarErro(tfDataNasc); tfDataNasc.requestFocus(); return;
        }

        // 4. Persiste no banco
        try {
            int ignorarId = alunoEditando != null ? alunoEditando.getId() : 0;
            if (dao.rgmExiste(tfRgm.getText().trim(), ignorarId)) {
                mostrarFeedback(false, "❌  Já existe um aluno cadastrado com este RGM.");
                marcarErro(tfRgm); return;
            }

            Aluno a = (alunoEditando != null) ? alunoEditando : new Aluno();
            a.setRgm     (tfRgm.getText().trim());
            a.setNome    (tfNome.getText().trim());
            a.setCpf     (tfCpf.getText().trim());
            a.setCelular (tfCelular.getText().trim());
            a.setEmail   (tfEmail.getText().trim());
            a.setDataNasc(dataNasc);
            a.setEndereco(tfEndereco.getText().trim());
            a.setCurso   ((String) cbCurso.getSelectedItem());
            a.setPeriodo ((String) cbPeriodo.getSelectedItem());
            a.setStatus  ((String) cbStatus.getSelectedItem());

            if (alunoEditando == null) {
                dao.inserir(a);
                mostrarFeedback(true, "✅  Aluno \"" + a.getNome() + "\" cadastrado com sucesso no banco de dados!");
            } else {
                dao.atualizar(a);
                mostrarFeedback(true, "✅  Aluno \"" + a.getNome() + "\" atualizado com sucesso!");
            }

            limparForm();
            carregarTabela(null);
            tabbedPane.setSelectedIndex(1);

        } catch (SQLException ex) {
            mostrarFeedback(false, "❌  Erro ao salvar: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private void carregarTabela(String filtro) {
        try {
            tableModel.setRowCount(0);
            List<Aluno> lista = (filtro == null || filtro.isEmpty())
                    ? dao.listarTodos() : dao.buscarPorNome(filtro);
            for (Aluno a : lista) {
                tableModel.addRow(new Object[]{
                    a.getId(), a.getRgm(), a.getNome(), a.getCpf(),
                    a.getCelular(), a.getCurso(), a.getPeriodo(), a.getStatus()
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar alunos:\n" + ex.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void excluir() {
        int id;
        if (alunoEditando != null) {
            id = alunoEditando.getId();
        } else {
            int row = table.getSelectedRow();
            if (row < 0) { JOptionPane.showMessageDialog(this, "Selecione um aluno para excluir."); return; }
            id = (int) tableModel.getValueAt(row, 0);
        }
        int r = JOptionPane.showConfirmDialog(this,
                "Confirma a exclusão? Notas e faltas também serão removidas.",
                "Confirmar Exclusão", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (r == JOptionPane.YES_OPTION) {
            try {
                dao.excluir(id);
                limparForm();
                carregarTabela(null);
                JOptionPane.showMessageDialog(this, "Aluno excluído com sucesso.");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Erro ao excluir:\n" + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void carregarParaEditar() {
        int row = table.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Selecione um aluno na tabela."); return; }
        int id = (int) tableModel.getValueAt(row, 0);
        try {
            alunoEditando = dao.buscarPorId(id);
            if (alunoEditando == null) return;
            tfRgm.setText(alunoEditando.getRgm());
            tfRgm.setEditable(false);
            tfNome.setText(alunoEditando.getNome());
            tfCpf.setValue(alunoEditando.getCpf());
            tfCelular.setValue(alunoEditando.getCelular());
            tfEmail.setText(alunoEditando.getEmail());
            tfEndereco.setText(alunoEditando.getEndereco());
            cbCurso.setSelectedItem(alunoEditando.getCurso());
            cbPeriodo.setSelectedItem(alunoEditando.getPeriodo());
            cbStatus.setSelectedItem(alunoEditando.getStatus());
            if (alunoEditando.getDataNasc() != null)
                tfDataNasc.setValue(alunoEditando.getDataNasc()
                        .format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
            tabbedPane.setSelectedIndex(0);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro:\n" + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void limparForm() {
        alunoEditando = null;
        tfRgm.setText(""); tfRgm.setEditable(true);
        tfNome.setText(""); tfEmail.setText(""); tfEndereco.setText("");
        tfCpf.setValue(null); tfCelular.setValue(null); tfDataNasc.setValue(null);
        cbCurso.setSelectedIndex(0); cbPeriodo.setSelectedIndex(0); cbStatus.setSelectedIndex(0);
    }
}
