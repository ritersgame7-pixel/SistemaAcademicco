package escola.ui;

import escola.dao.*;
import escola.model.*;
import escola.util.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.print.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Boletim Escolar – exibe notas e frequência do aluno em formato de
 * boletim visual com indicadores de aprovação/reprovação.
 */
public class BoletimPanel extends JPanel {

    private final AlunoDAO      alunoDAO      = new AlunoDAO();
    private final NotaDAO       notaDAO       = new NotaDAO();
    private final FaltaDAO      faltaDAO      = new FaltaDAO();
    private final DisciplinaDAO disciplinaDAO = new DisciplinaDAO();

    private JComboBox<Aluno> cbAluno;
    private JTextField       tfSemestre;
    private JPanel           boletimContainer;
    private Aluno            alunoAtual;

    public BoletimPanel() {
        setLayout(new BorderLayout());
        setBackground(UITheme.BG_PANEL);
        add(buildHeader(),    BorderLayout.NORTH);
        add(buildContent(),   BorderLayout.CENTER);
        carregarAlunos();
    }

    // ── Header ────────────────────────────────────────────────────────────
    private JPanel buildHeader() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(new Color(0x1B5E20));
        p.setBorder(BorderFactory.createEmptyBorder(14,20,14,20));
        JLabel l = new JLabel("📄  Boletim Escolar");
        l.setFont(UITheme.FONT_TITLE); l.setForeground(Color.WHITE);
        p.add(l, BorderLayout.WEST);
        return p;
    }

    // ── Painel de seleção + boletim ───────────────────────────────────────
    private JPanel buildContent() {
        JPanel root = new JPanel(new BorderLayout(0,12));
        root.setBackground(UITheme.BG_PANEL);
        root.setBorder(BorderFactory.createEmptyBorder(15,20,15,20));

        // ---- barra de seleção ----
        JPanel barSelect = new JPanel(new FlowLayout(FlowLayout.LEFT,12,6));
        barSelect.setBackground(UITheme.BG_CARD);
        barSelect.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER),
                BorderFactory.createEmptyBorder(8,14,8,14)));

        cbAluno    = new JComboBox<>();
        cbAluno.setFont(UITheme.FONT_BODY);
        cbAluno.setPreferredSize(new Dimension(280,32));
        tfSemestre = new JTextField("2024.1",8);
        tfSemestre.setFont(UITheme.FONT_BODY);

        StyledButton btnGerar   = StyledButton.success("📄  Gerar Boletim");
        StyledButton btnImprimir= StyledButton.primary("🖨  Imprimir");

        btnGerar  .addActionListener(e -> gerarBoletim());
        btnImprimir.addActionListener(e -> imprimir());

        barSelect.add(new JLabel("Aluno:"));
        barSelect.add(cbAluno);
        barSelect.add(Box.createHorizontalStrut(10));
        barSelect.add(new JLabel("Semestre:"));
        barSelect.add(tfSemestre);
        barSelect.add(Box.createHorizontalStrut(10));
        barSelect.add(btnGerar);
        barSelect.add(btnImprimir);

        // ---- container do boletim ----
        boletimContainer = new JPanel(new BorderLayout());
        boletimContainer.setBackground(UITheme.BG_PANEL);
        boletimContainer.add(buildPlaceholder(), BorderLayout.CENTER);

        JScrollPane scroll = new JScrollPane(boletimContainer);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(UITheme.BG_PANEL);

        root.add(barSelect, BorderLayout.NORTH);
        root.add(scroll,    BorderLayout.CENTER);
        return root;
    }

    private JPanel buildPlaceholder() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(UITheme.BG_PANEL);
        JLabel l = new JLabel("Selecione um aluno e clique em Gerar Boletim");
        l.setFont(new Font("Segoe UI", Font.ITALIC, 16));
        l.setForeground(UITheme.TEXT_MUTED);
        p.add(l);
        return p;
    }

    // ── Lógica ───────────────────────────────────────────────────────────
    private void carregarAlunos() {
        try {
            cbAluno.removeAllItems();
            for (Aluno a : alunoDAO.listarTodos()) cbAluno.addItem(a);
        } catch(SQLException ex) {
            JOptionPane.showMessageDialog(this,"Erro ao carregar alunos:\n"+ex.getMessage(),"Erro",JOptionPane.ERROR_MESSAGE);
        }
    }

    private void gerarBoletim() {
        alunoAtual = (Aluno) cbAluno.getSelectedItem();
        if (alunoAtual == null) { JOptionPane.showMessageDialog(this,"Selecione um aluno."); return; }
        String sem = tfSemestre.getText().trim();

        try {
            List<Nota>  notas  = notaDAO .listarPorAluno(alunoAtual.getId());
            List<Falta> faltas = faltaDAO.listarPorAluno(alunoAtual.getId());

            // filtra por semestre
            notas .removeIf(n -> !sem.isEmpty() && !n.getSemestre().equals(sem));
            faltas.removeIf(f -> !sem.isEmpty() && !f.getSemestre().equals(sem));

            JPanel boletim = buildBoletimCard(alunoAtual, sem, notas, faltas);

            boletimContainer.removeAll();
            boletimContainer.add(boletim, BorderLayout.CENTER);
            boletimContainer.revalidate();
            boletimContainer.repaint();

        } catch(SQLException ex) {
            JOptionPane.showMessageDialog(this,"Erro:\n"+ex.getMessage(),"Erro",JOptionPane.ERROR_MESSAGE);
        }
    }

    // ── Constrói o card visual do boletim ─────────────────────────────────
    private JPanel buildBoletimCard(Aluno a, String semestre, List<Nota> notas, List<Falta> faltas) {

        JPanel outer = new JPanel(new BorderLayout());
        outer.setBackground(UITheme.BG_PANEL);
        outer.setBorder(BorderFactory.createEmptyBorder(10,20,10,20));

        // ---- card branco ----
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xCCCCCC),1,true),
                BorderFactory.createEmptyBorder(0,0,20,0)));

        // ---- topo colorido ----
        JPanel topo = new JPanel(new GridLayout(1,2));
        topo.setBackground(UITheme.PRIMARY);
        topo.setBorder(BorderFactory.createEmptyBorder(16,20,16,20));

        JPanel esquerda = new JPanel(new GridLayout(3,1,2,2));
        esquerda.setOpaque(false);
        JLabel lInst = new JLabel("SISTEMA DE ENSINO");
        lInst.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lInst.setForeground(new Color(0xB0C4DE));
        JLabel lTitulo = new JLabel("BOLETIM ESCOLAR");
        lTitulo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lTitulo.setForeground(Color.WHITE);
        JLabel lSem = new JLabel("Semestre: " + (semestre.isBlank() ? "Todos" : semestre));
        lSem.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lSem.setForeground(UITheme.ACCENT);
        esquerda.add(lInst); esquerda.add(lTitulo); esquerda.add(lSem);

        JPanel direita = new JPanel(new GridLayout(4,1,2,2));
        direita.setOpaque(false);
        Font fInfo = new Font("Segoe UI", Font.PLAIN, 12);
        Color cInfo = new Color(0xD0E8FF);
        JLabel lNome = new JLabel("Aluno: " + a.getNome());
        JLabel lRgm  = new JLabel("RGM:   " + a.getRgm());
        JLabel lCurso= new JLabel("Curso: " + a.getCurso());
        String dn = a.getDataNasc()!=null ? a.getDataNasc().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) : "-";
        JLabel lData = new JLabel("Data Nasc.: " + dn);
        for(JLabel l2 : new JLabel[]{lNome,lRgm,lCurso,lData}){
            l2.setFont(fInfo); l2.setForeground(cInfo);
        }
        lNome.setFont(new Font("Segoe UI",Font.BOLD,13)); lNome.setForeground(Color.WHITE);
        direita.add(lNome); direita.add(lRgm); direita.add(lCurso); direita.add(lData);

        topo.add(esquerda); topo.add(direita);

        // ---- tabela de notas ----
        String[] cols = {"Disciplina","AV1","AV2","AV3","AV4","Média","Nota Final","Situação","Faltas","Freq.%"};
        DefaultTableModel tm = new DefaultTableModel(cols,0){
            public boolean isCellEditable(int r,int c){return false;}
        };

        double somaMedicas = 0; int count=0;
        boolean algumReprovado = false;

        for(Nota n : notas) {
            double freq = 100;
            int    falts = 0;
            for(Falta f : faltas)
                if(f.getDisciplinaId()==n.getDisciplinaId()){ freq=f.getPercentualFreq(); falts=f.getTotalFaltas(); break;}

            somaMedicas += n.getMedia(); count++;
            if("Reprovado".equals(n.getSituacao())) algumReprovado = true;

            tm.addRow(new Object[]{
                n.getNomeDisciplina(),
                String.format("%.1f",n.getAv1()), String.format("%.1f",n.getAv2()),
                String.format("%.1f",n.getAv3()), String.format("%.1f",n.getAv4()),
                String.format("%.2f",n.getMedia()),
                String.format("%.2f",n.getNotaFinal()),
                n.getSituacao(), falts, String.format("%.1f%%",freq)
            });
        }

        JTable tblNota = new JTable(tm);
        tblNota.setFont(new Font("Segoe UI",Font.PLAIN,12));
        tblNota.setRowHeight(26);
        tblNota.setGridColor(new Color(0xE8EEF5));
        tblNota.setShowHorizontalLines(true); tblNota.setShowVerticalLines(false);
        tblNota.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,12));
        tblNota.getTableHeader().setBackground(UITheme.SECONDARY);
        tblNota.getTableHeader().setForeground(Color.WHITE);
        tblNota.setIntercellSpacing(new Dimension(6,0));

        // renderer situação
        tblNota.getColumnModel().getColumn(7).setCellRenderer(new DefaultTableCellRenderer(){
            public Component getTableCellRendererComponent(JTable t, Object v, boolean isSel,
                    boolean hasFocus, int row, int col){
                super.getTableCellRendererComponent(t,v,isSel,hasFocus,row,col);
                setHorizontalAlignment(CENTER);
                setFont(new Font("Segoe UI",Font.BOLD,11));
                if("Aprovado".equals(v)){ setBackground(new Color(0xE8F8F0)); setForeground(UITheme.SUCCESS); }
                else if("Reprovado".equals(v)){ setBackground(new Color(0xFDE8E8)); setForeground(UITheme.DANGER); }
                else { setBackground(new Color(0xFFF8E1)); setForeground(UITheme.WARNING); }
                setBorder(BorderFactory.createEmptyBorder(2,4,2,4));
                return this;
            }
        });

        // renderer média
        tblNota.getColumnModel().getColumn(5).setCellRenderer(new DefaultTableCellRenderer(){
            public Component getTableCellRendererComponent(JTable t, Object v, boolean isSel,
                    boolean hasFocus, int row, int col){
                super.getTableCellRendererComponent(t,v,isSel,hasFocus,row,col);
                setHorizontalAlignment(CENTER);
                setFont(new Font("Segoe UI",Font.BOLD,12));
                try{
                    double val = Double.parseDouble(v.toString().replace(",","."));
                    setForeground(val>=6.0 ? UITheme.SUCCESS : UITheme.DANGER);
                } catch(Exception ignored){}
                return this;
            }
        });

        // renderer freq
        tblNota.getColumnModel().getColumn(9).setCellRenderer(new DefaultTableCellRenderer(){
            public Component getTableCellRendererComponent(JTable t, Object v, boolean isSel,
                    boolean hasFocus, int row, int col){
                super.getTableCellRendererComponent(t,v,isSel,hasFocus,row,col);
                setHorizontalAlignment(CENTER);
                try{
                    double val = Double.parseDouble(v.toString().replace(",",".").replace("%",""));
                    setForeground(val<75 ? UITheme.DANGER : UITheme.SUCCESS);
                    setFont(new Font("Segoe UI",Font.BOLD,11));
                } catch(Exception ignored){}
                return this;
            }
        });

        JScrollPane scTab = new JScrollPane(tblNota);
        scTab.setBorder(BorderFactory.createEmptyBorder());
        scTab.setPreferredSize(new Dimension(800, Math.max(120, notas.size()*27+40)));

        // ---- rodapé ----
        JPanel rodape = new JPanel(new GridLayout(1,3,10,0));
        rodape.setBackground(new Color(0xF7F9FC));
        rodape.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1,0,0,0,UITheme.BORDER),
                BorderFactory.createEmptyBorder(12,20,12,20)));

        double mediaGeral = count>0 ? somaMedicas/count : 0;
        String statusFinal = notas.isEmpty() ? "—" : (!algumReprovado && mediaGeral>=6.0 ? "APROVADO" : "REPROVADO");
        Color  corStatus   = "APROVADO".equals(statusFinal) ? UITheme.SUCCESS
                           : "REPROVADO".equals(statusFinal) ? UITheme.DANGER : UITheme.TEXT_MUTED;

        rodape.add(buildStatCard("Média Geral", String.format("%.2f", mediaGeral),
                mediaGeral>=6.0 ? UITheme.SUCCESS : UITheme.DANGER));
        rodape.add(buildStatCard("Disciplinas", count + " cursadas", UITheme.SECONDARY));
        rodape.add(buildStatCard("Situação Final", statusFinal, corStatus));

        // ---- compõe card ----
        JPanel scWrapper = new JPanel(new BorderLayout());
        scWrapper.setBackground(Color.WHITE);
        scWrapper.setBorder(BorderFactory.createEmptyBorder(0,16,0,16));
        JLabel lblSec = new JLabel("  Desempenho Acadêmico");
        lblSec.setFont(new Font("Segoe UI",Font.BOLD,13));
        lblSec.setForeground(UITheme.PRIMARY);
        lblSec.setBorder(BorderFactory.createEmptyBorder(12,0,8,0));
        scWrapper.add(lblSec,  BorderLayout.NORTH);
        scWrapper.add(scTab,   BorderLayout.CENTER);

        card.add(topo);
        card.add(Box.createVerticalStrut(10));
        card.add(scWrapper);
        card.add(Box.createVerticalStrut(10));
        card.add(rodape);

        outer.add(card, BorderLayout.CENTER);
        return outer;
    }

    private JPanel buildStatCard(String title, String value, Color valueColor) {
        JPanel p = new JPanel(new GridLayout(2,1,2,2));
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createEmptyBorder(4,12,4,12));
        JLabel lt = new JLabel(title, SwingConstants.CENTER);
        lt.setFont(new Font("Segoe UI",Font.PLAIN,11));
        lt.setForeground(UITheme.TEXT_MUTED);
        JLabel lv = new JLabel(value, SwingConstants.CENTER);
        lv.setFont(new Font("Segoe UI",Font.BOLD,18));
        lv.setForeground(valueColor);
        p.add(lt); p.add(lv);
        return p;
    }

    private void imprimir() {
        if (alunoAtual==null){ JOptionPane.showMessageDialog(this,"Gere o boletim primeiro."); return;}
        PrinterJob pj = PrinterJob.getPrinterJob();
        pj.setJobName("Boletim - " + alunoAtual.getNome());
        pj.setPrintable((graphics, pageFormat, pageIndex) -> {
            if(pageIndex>0) return Printable.NO_SUCH_PAGE;
            Graphics2D g2=(Graphics2D) graphics;
            g2.translate(pageFormat.getImageableX(), pageFormat.getImageableY());
            double sw = pageFormat.getImageableWidth();
            double sh = pageFormat.getImageableHeight();
            double cw = boletimContainer.getWidth();
            double ch = boletimContainer.getHeight();
            double scale = Math.min(sw/cw, sh/ch);
            g2.scale(scale,scale);
            boletimContainer.printAll(g2);
            return Printable.PAGE_EXISTS;
        });
        if(pj.printDialog()) {
            try { pj.print(); }
            catch(PrinterException ex){ JOptionPane.showMessageDialog(this,"Erro ao imprimir:\n"+ex.getMessage(),"Erro",JOptionPane.ERROR_MESSAGE); }
        }
    }
}
