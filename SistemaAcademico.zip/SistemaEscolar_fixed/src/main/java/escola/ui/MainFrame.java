package escola.ui;

import escola.connection.ConnectionFactory;
import escola.util.*;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;

/**
 * Janela principal do Sistema Escolar.
 * Lateral de navegação + área de conteúdo com JTabbedPane oculto.
 */
public class MainFrame extends JFrame {

    private static final int SIDEBAR_W = 200;

    private JPanel contentArea;
    private CardLayout cardLayout;

    // Painéis das telas
    private JPanel dashBoard;
    private AlunoPanel      alunoPanel;
    private DisciplinaPanel disciplinaPanel;
    private NotaPanel       notaPanel;
    private FaltaPanel      faltaPanel;
    private BoletimPanel    boletimPanel;

    public MainFrame() {
        super("Sistema Escolar — Gestão Acadêmica");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(1180, 740);
        setMinimumSize(new Dimension(900, 600));
        setLocationRelativeTo(null);

        setLayout(new BorderLayout());
        add(buildSidebar(),   BorderLayout.WEST);
        add(buildContent(),   BorderLayout.CENTER);

        // Inicializa painéis (lazy = falso para pré-warm)
        alunoPanel      = new AlunoPanel();
        disciplinaPanel = new DisciplinaPanel();
        notaPanel       = new NotaPanel();
        faltaPanel      = new FaltaPanel();
        boletimPanel    = new BoletimPanel();

        contentArea.add(buildDashboard(), "dashboard");
        contentArea.add(alunoPanel,       "alunos");
        contentArea.add(disciplinaPanel,  "disciplinas");
        contentArea.add(notaPanel,        "notas");
        contentArea.add(faltaPanel,       "faltas");
        contentArea.add(boletimPanel,     "boletim");

        cardLayout.show(contentArea, "dashboard");

        // Fecha a conexão ao sair
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { ConnectionFactory.close(); }
        });
    }

    // ── SIDEBAR ───────────────────────────────────────────────────────────
    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(UITheme.PRIMARY);
        sidebar.setPreferredSize(new Dimension(SIDEBAR_W, 0));

        // Logo / título
        JPanel logo = new JPanel(new BorderLayout());
        logo.setBackground(new Color(0x0F2540));
        logo.setBorder(BorderFactory.createEmptyBorder(20, 16, 20, 16));
        logo.setMaximumSize(new Dimension(SIDEBAR_W, 90));
        JLabel lIcon = new JLabel("🎓", SwingConstants.CENTER);
        lIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 32));
        JLabel lTitle = new JLabel("SistEscolar", SwingConstants.CENTER);
        lTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lTitle.setForeground(Color.WHITE);
        logo.add(lIcon,  BorderLayout.CENTER);
        logo.add(lTitle, BorderLayout.SOUTH);
        sidebar.add(logo);
        sidebar.add(Box.createVerticalStrut(12));

        // Botões de navegação
        sidebar.add(navBtn("🏠", "Dashboard",    "dashboard"));
        sidebar.add(navBtn("👨‍🎓", "Alunos",       "alunos"));
        sidebar.add(navBtn("📚", "Disciplinas",  "disciplinas"));
        sidebar.add(navBtn("📝", "Notas",        "notas"));
        sidebar.add(navBtn("📋", "Faltas",       "faltas"));
        sidebar.add(navBtn("📄", "Boletim",      "boletim"));

        sidebar.add(Box.createVerticalGlue());

        // Rodapé versão
        JLabel ver = new JLabel("v1.0 — Java Swing", SwingConstants.CENTER);
        ver.setFont(UITheme.FONT_SMALL);
        ver.setForeground(new Color(0x7A9ABB));
        ver.setAlignmentX(Component.CENTER_ALIGNMENT);
        ver.setBorder(BorderFactory.createEmptyBorder(8,0,12,0));
        sidebar.add(ver);

        return sidebar;
    }

    private JButton navBtn(String icon, String label, String card) {
        JButton btn = new JButton(icon + "  " + label);
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btn.setForeground(new Color(0xB0C8E8));
        btn.setBackground(UITheme.PRIMARY);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 18, 10, 18));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setMaximumSize(new Dimension(SIDEBAR_W, 44));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) {
                btn.setBackground(new Color(0x2E5F8E));
                btn.setForeground(Color.WHITE);
            }
            @Override public void mouseExited(MouseEvent e) {
                btn.setBackground(UITheme.PRIMARY);
                btn.setForeground(new Color(0xB0C8E8));
            }
        });

        btn.addActionListener(e -> cardLayout.show(contentArea, card));
        return btn;
    }

    // ── CONTENT AREA ─────────────────────────────────────────────────────
    private JPanel buildContent() {
        cardLayout  = new CardLayout();
        contentArea = new JPanel(cardLayout);
        contentArea.setBackground(UITheme.BG_PANEL);
        return contentArea;
    }

    // ── DASHBOARD ─────────────────────────────────────────────────────────
    private JLabel lblTotalAlunos, lblTotalDisc, lblTotalNotas, lblTotalFaltas;

    private JPanel buildDashboard() {
        JPanel root = new JPanel(new BorderLayout(0, 0));
        root.setBackground(UITheme.BG_PANEL);

        // header
        JPanel hdr = new JPanel(new BorderLayout());
        hdr.setBackground(UITheme.PRIMARY);
        hdr.setBorder(BorderFactory.createEmptyBorder(18,24,18,24));
        JLabel h = new JLabel("🏠  Painel Principal");
        h.setFont(UITheme.FONT_TITLE); h.setForeground(Color.WHITE);
        hdr.add(h, BorderLayout.WEST);

        // ── linha de resumo (contadores) ──
        JPanel statsRow = new JPanel(new GridLayout(1, 4, 12, 0));
        statsRow.setBackground(UITheme.BG_PANEL);
        statsRow.setBorder(BorderFactory.createEmptyBorder(18, 24, 6, 24));

        lblTotalAlunos  = new JLabel("0", SwingConstants.CENTER);
        lblTotalDisc    = new JLabel("0", SwingConstants.CENTER);
        lblTotalNotas   = new JLabel("0", SwingConstants.CENTER);
        lblTotalFaltas  = new JLabel("0", SwingConstants.CENTER);

        statsRow.add(statCard("👨‍🎓 Alunos",      lblTotalAlunos,  UITheme.SECONDARY));
        statsRow.add(statCard("📚 Disciplinas",  lblTotalDisc,    new Color(0x4A235A)));
        statsRow.add(statCard("📝 Notas",        lblTotalNotas,   UITheme.SUCCESS));
        statsRow.add(statCard("📋 Faltas",       lblTotalFaltas,  new Color(0x6C3483)));

        // ── tabela de alunos recentes ──
        String[] cols = {"RGM", "Nome", "Curso", "Período", "Status"};
        javax.swing.table.DefaultTableModel recentModel = new javax.swing.table.DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable recentTable = new JTable(recentModel);
        recentTable.setFont(UITheme.FONT_BODY);
        recentTable.setRowHeight(26);
        recentTable.setGridColor(UITheme.BORDER);
        recentTable.setShowHorizontalLines(true);
        recentTable.setShowVerticalLines(false);
        javax.swing.table.JTableHeader th = recentTable.getTableHeader();
        th.setFont(UITheme.FONT_LABEL);
        th.setBackground(UITheme.TABLE_HEADER);
        th.setForeground(Color.WHITE);
        th.setReorderingAllowed(false);
        recentTable.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, v, sel, foc, row, col);
                if (!sel) setBackground(row % 2 == 0 ? Color.WHITE : UITheme.TABLE_STRIPE);
                setBorder(BorderFactory.createEmptyBorder(0, 6, 0, 6));
                return this;
            }
        });

        JScrollPane tableScroll = new JScrollPane(recentTable);
        tableScroll.setBorder(BorderFactory.createLineBorder(UITheme.BORDER));

        JPanel tablePanel = new JPanel(new BorderLayout(0, 6));
        tablePanel.setBackground(UITheme.BG_PANEL);
        tablePanel.setBorder(BorderFactory.createEmptyBorder(6, 24, 18, 24));
        JLabel tableTitle = new JLabel("📋  Alunos Cadastrados");
        tableTitle.setFont(UITheme.FONT_SUBTITLE);
        tableTitle.setForeground(UITheme.TEXT_DARK);
        tablePanel.add(tableTitle,  BorderLayout.NORTH);
        tablePanel.add(tableScroll, BorderLayout.CENTER);

        // ── botão atualizar ──
        StyledButton btnRefresh = StyledButton.primary("↻  Atualizar Dashboard");
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 24, 6));
        btnRow.setOpaque(false);
        btnRow.add(btnRefresh);

        // ── monta root ──
        JPanel center = new JPanel(new BorderLayout(0, 0));
        center.setBackground(UITheme.BG_PANEL);
        center.add(statsRow,   BorderLayout.NORTH);
        center.add(tablePanel, BorderLayout.CENTER);
        center.add(btnRow,     BorderLayout.SOUTH);

        root.add(hdr,    BorderLayout.NORTH);
        root.add(center, BorderLayout.CENTER);

        // carrega dados iniciais e ao clicar em atualizar
        Runnable refresh = () -> {
            try {
                java.sql.Connection conn = escola.connection.ConnectionFactory.getConnection();

                // contadores
                try (java.sql.Statement st = conn.createStatement()) {
                    java.sql.ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM alunos");
                    lblTotalAlunos.setText(rs.next() ? String.valueOf(rs.getInt(1)) : "0");
                    rs = st.executeQuery("SELECT COUNT(*) FROM disciplinas");
                    lblTotalDisc.setText(rs.next() ? String.valueOf(rs.getInt(1)) : "0");
                    rs = st.executeQuery("SELECT COUNT(*) FROM notas");
                    lblTotalNotas.setText(rs.next() ? String.valueOf(rs.getInt(1)) : "0");
                    rs = st.executeQuery("SELECT COUNT(*) FROM faltas");
                    lblTotalFaltas.setText(rs.next() ? String.valueOf(rs.getInt(1)) : "0");
                }

                // tabela de alunos
                recentModel.setRowCount(0);
                try (java.sql.Statement st = conn.createStatement();
                     java.sql.ResultSet rs = st.executeQuery(
                             "SELECT rgm, nome, curso, periodo, status FROM alunos ORDER BY nome")) {
                    while (rs.next()) {
                        recentModel.addRow(new Object[]{
                            rs.getString("rgm"),
                            rs.getString("nome"),
                            rs.getString("curso"),
                            rs.getString("periodo"),
                            rs.getString("status")
                        });
                    }
                }
            } catch (java.sql.SQLException ex) {
                System.err.println("Dashboard refresh error: " + ex.getMessage());
            }
        };

        btnRefresh.addActionListener(e -> refresh.run());

        // atualiza ao mostrar o painel
        root.addAncestorListener(new javax.swing.event.AncestorListener() {
            @Override public void ancestorAdded(javax.swing.event.AncestorEvent e) { refresh.run(); }
            @Override public void ancestorRemoved(javax.swing.event.AncestorEvent e) {}
            @Override public void ancestorMoved(javax.swing.event.AncestorEvent e) {}
        });

        return root;
    }

    private JPanel statCard(String title, JLabel valueLabel, Color color) {
        JPanel p = new JPanel(new BorderLayout(0, 4));
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xDDE3ED), 1, true),
                BorderFactory.createEmptyBorder(14, 16, 14, 16)));

        JPanel bar = new JPanel();
        bar.setBackground(color);
        bar.setPreferredSize(new Dimension(0, 5));

        JLabel lTitle = new JLabel(title);
        lTitle.setFont(UITheme.FONT_LABEL);
        lTitle.setForeground(UITheme.TEXT_MUTED);

        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 32));
        valueLabel.setForeground(color);

        p.add(bar,        BorderLayout.NORTH);
        p.add(lTitle,     BorderLayout.CENTER);
        p.add(valueLabel, BorderLayout.SOUTH);
        return p;
    }

    private JPanel quickCard(String icon, String title, String desc, Color color, String card) {
        JPanel p = new JPanel(new BorderLayout(0,8));
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xDDE3ED),1,true),
                BorderFactory.createEmptyBorder(20,20,20,20)));
        p.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        JLabel ico = new JLabel(icon, SwingConstants.LEFT);
        ico.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 34));

        JPanel txt = new JPanel(new GridLayout(2,1,0,4));
        txt.setOpaque(false);
        JLabel lt = new JLabel(title); lt.setFont(UITheme.FONT_SUBTITLE); lt.setForeground(UITheme.TEXT_DARK);
        JLabel ld = new JLabel(desc);  ld.setFont(UITheme.FONT_SMALL);    ld.setForeground(UITheme.TEXT_MUTED);
        txt.add(lt); txt.add(ld);

        // barra colorida no topo
        JPanel bar = new JPanel(); bar.setBackground(color);
        bar.setPreferredSize(new Dimension(0,5));

        p.add(bar, BorderLayout.NORTH);
        p.add(ico, BorderLayout.WEST);
        p.add(txt, BorderLayout.CENTER);

        p.addMouseListener(new MouseAdapter(){
            @Override public void mouseClicked(MouseEvent e){ cardLayout.show(contentArea, card); }
            @Override public void mouseEntered(MouseEvent e){ p.setBackground(new Color(0xF0F5FF)); }
            @Override public void mouseExited (MouseEvent e){ p.setBackground(Color.WHITE); }
        });
        return p;
    }

    private JPanel buildInfoCard() {
        JPanel p = new JPanel(new GridLayout(3,1,4,4));
        p.setBackground(new Color(0xFFF8E1));
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.ACCENT,1,true),
                BorderFactory.createEmptyBorder(16,18,16,18)));
        JLabel h = new JLabel("ℹ️  Informações do Sistema");
        h.setFont(UITheme.FONT_LABEL); h.setForeground(UITheme.TEXT_DARK);
        JLabel l1 = new JLabel("• Aprovação: Média ≥ 6,0");
        JLabel l2 = new JLabel("• Frequência mínima: 75%");
        for(JLabel l : new JLabel[]{l1,l2}){
            l.setFont(UITheme.FONT_SMALL); l.setForeground(UITheme.TEXT_DARK);
        }
        p.add(h); p.add(l1); p.add(l2);
        return p;
    }

    // ── MAIN ──────────────────────────────────────────────────────────────
    public static void main(String[] args) {
        // Testa conexão antes de abrir
        try {
            ConnectionFactory.getConnection();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,
                    "Não foi possível inicializar o banco de dados SQLite.\n\n"
                    + ex.getMessage(),
                    "Erro de Conexão", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}
