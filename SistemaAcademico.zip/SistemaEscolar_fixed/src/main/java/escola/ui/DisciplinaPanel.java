package escola.ui;

import escola.dao.DisciplinaDAO;
import escola.model.Disciplina;
import escola.util.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

/**
 * Painel de Cadastro de Disciplinas com JTabbedPane.
 */
public class DisciplinaPanel extends JPanel {

    private final DisciplinaDAO dao = new DisciplinaDAO();
    private Disciplina editando;

    private JTextField tfCodigo, tfNome, tfCargaHora;
    private JComboBox<String> cbPeriodo;
    private JTextField tfCurso;

    private JTable table;
    private DefaultTableModel tableModel;
    private JTabbedPane tp;

    public DisciplinaPanel() {
        setLayout(new BorderLayout());
        setBackground(UITheme.BG_PANEL);
        add(buildHeader(), BorderLayout.NORTH);

        tp = new JTabbedPane();
        tp.setFont(UITheme.FONT_SUBTITLE);
        tp.addTab("➕  Cadastro",  buildCadastroTab());
        tp.addTab("📋  Listagem",  buildListagemTab());
        add(tp, BorderLayout.CENTER);

        carregarTabela();
    }

    private JPanel buildHeader() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(new Color(0x4A235A));
        p.setBorder(BorderFactory.createEmptyBorder(14,20,14,20));
        JLabel l = new JLabel("📚  Disciplinas");
        l.setFont(UITheme.FONT_TITLE); l.setForeground(Color.WHITE);
        p.add(l, BorderLayout.WEST);
        return p;
    }

    private JPanel buildCadastroTab() {
        JPanel root = new JPanel(new BorderLayout(0,10));
        root.setBackground(UITheme.BG_PANEL);
        root.setBorder(BorderFactory.createEmptyBorder(15,15,15,15));

        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(UITheme.BG_CARD);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER),
                BorderFactory.createEmptyBorder(20,24,20,24)));

        GridBagConstraints g = new GridBagConstraints();
        g.insets=new Insets(5,6,5,6); g.anchor=GridBagConstraints.WEST;
        g.fill=GridBagConstraints.HORIZONTAL;

        tfCodigo    = new JTextField(10);
        tfNome      = new JTextField(30);
        tfCargaHora = new JTextField("60",6);
        tfCurso     = new JTextField(25);
        cbPeriodo   = new JComboBox<>(new String[]{"1º","2º","3º","4º","5º","6º","7º","8º"});

        row(card,g,"Código *",    tfCodigo,   0,0);
        row(card,g,"Nome *",      tfNome,     2,0);
        row(card,g,"Carga Horária",tfCargaHora,0,1);
        row(card,g,"Período",     cbPeriodo,  2,1);
        row(card,g,"Curso",       tfCurso,    4,1);

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.CENTER,10,4));
        btns.setOpaque(false);
        StyledButton bs = StyledButton.success("💾  Salvar");
        StyledButton bl = StyledButton.primary("🔄  Limpar");
        StyledButton bd = StyledButton.danger ("🗑  Excluir");
        bs.addActionListener(e->salvar());
        bl.addActionListener(e->limpar());
        bd.addActionListener(e->excluir());
        btns.add(bs); btns.add(bl); btns.add(bd);

        JScrollPane sc = new JScrollPane(card);
        sc.setBorder(null); sc.getViewport().setBackground(UITheme.BG_PANEL);
        root.add(sc,   BorderLayout.CENTER);
        root.add(btns, BorderLayout.SOUTH);
        return root;
    }

    private void row(JPanel p, GridBagConstraints g, String lbl, JComponent c, int col, int row){
        JLabel l = new JLabel(lbl); l.setFont(UITheme.FONT_LABEL);
        g.gridx=col; g.gridy=row*2;   p.add(l,g);
        g.gridx=col; g.gridy=row*2+1; p.add(c,g);
    }

    private JPanel buildListagemTab() {
        JPanel root = new JPanel(new BorderLayout(0,8));
        root.setBackground(UITheme.BG_PANEL);
        root.setBorder(BorderFactory.createEmptyBorder(12,15,12,15));

        String[] cols = {"ID","Código","Nome","Carga H.","Período","Curso"};
        tableModel = new DefaultTableModel(cols,0){
            public boolean isCellEditable(int r,int c){return false;}
        };
        table = new JTable(tableModel);
        table.setFont(UITheme.FONT_BODY); table.setRowHeight(28);
        table.getTableHeader().setFont(UITheme.FONT_LABEL);
        table.getTableHeader().setBackground(UITheme.TABLE_HEADER);
        table.getTableHeader().setForeground(Color.WHITE);
        table.getColumnModel().getColumn(0).setMinWidth(0);
        table.getColumnModel().getColumn(0).setMaxWidth(0);
        table.getColumnModel().getColumn(0).setWidth(0);

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT,8,4));
        top.setOpaque(false);
        StyledButton btnAtt = StyledButton.primary("↻  Atualizar");
        StyledButton btnEd  = StyledButton.warning("✏  Editar");
        btnAtt.addActionListener(e->carregarTabela());
        btnEd .addActionListener(e->carregarParaEditar());
        top.add(btnAtt); top.add(btnEd);

        root.add(top, BorderLayout.NORTH);
        root.add(new JScrollPane(table), BorderLayout.CENTER);
        return root;
    }

    private void carregarTabela(){
        try{
            tableModel.setRowCount(0);
            for(Disciplina d : dao.listarTodas())
                tableModel.addRow(new Object[]{d.getId(),d.getCodigo(),d.getNome(),d.getCargaHora(),d.getPeriodo(),d.getCurso()});
        } catch(SQLException ex){
            JOptionPane.showMessageDialog(this,"Erro:\n"+ex.getMessage(),"Erro",JOptionPane.ERROR_MESSAGE);
        }
    }

    private void salvar(){
        if(tfCodigo.getText().isBlank()||tfNome.getText().isBlank()){
            JOptionPane.showMessageDialog(this,"Código e Nome são obrigatórios.","Atenção",JOptionPane.WARNING_MESSAGE);return;
        }
        try{
            Disciplina d = editando!=null ? editando : new Disciplina();
            d.setCodigo(tfCodigo.getText().trim());
            d.setNome(tfNome.getText().trim());
            try{ d.setCargaHora(Integer.parseInt(tfCargaHora.getText().trim())); } catch(Exception e){ d.setCargaHora(60); }
            d.setPeriodo((String)cbPeriodo.getSelectedItem());
            d.setCurso(tfCurso.getText().trim());
            if(editando==null) dao.inserir(d); else dao.atualizar(d);
            JOptionPane.showMessageDialog(this,"Disciplina salva!","Sucesso",JOptionPane.INFORMATION_MESSAGE);
            limpar(); carregarTabela(); tp.setSelectedIndex(1);
        } catch(SQLException ex){
            JOptionPane.showMessageDialog(this,"Erro:\n"+ex.getMessage(),"Erro",JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarParaEditar(){
        int row=table.getSelectedRow();
        if(row<0){JOptionPane.showMessageDialog(this,"Selecione uma disciplina.");return;}
        editando = new Disciplina();
        editando.setId((int)tableModel.getValueAt(row,0));
        tfCodigo.setText(tableModel.getValueAt(row,1).toString());
        tfNome.setText(tableModel.getValueAt(row,2).toString());
        tfCargaHora.setText(tableModel.getValueAt(row,3).toString());
        cbPeriodo.setSelectedItem(tableModel.getValueAt(row,4));
        tfCurso.setText(tableModel.getValueAt(row,5)!=null?tableModel.getValueAt(row,5).toString():"");
        tp.setSelectedIndex(0);
    }

    private void excluir(){
        int row=table.getSelectedRow();
        if(row<0&&editando==null){JOptionPane.showMessageDialog(this,"Selecione uma disciplina.");return;}
        int id = editando!=null ? editando.getId() : (int)tableModel.getValueAt(row,0);
        if(JOptionPane.showConfirmDialog(this,"Excluir disciplina?","Confirmar",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION){
            try{ dao.excluir(id); limpar(); carregarTabela(); }
            catch(SQLException ex){ JOptionPane.showMessageDialog(this,"Erro:\n"+ex.getMessage(),"Erro",JOptionPane.ERROR_MESSAGE); }
        }
    }

    private void limpar(){
        editando=null;
        tfCodigo.setText(""); tfNome.setText(""); tfCargaHora.setText("60"); tfCurso.setText("");
        cbPeriodo.setSelectedIndex(0);
    }
}
