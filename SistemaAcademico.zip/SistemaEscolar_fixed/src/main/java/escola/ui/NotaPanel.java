package escola.ui;

import escola.dao.*;
import escola.model.*;
import escola.util.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

/**
 * Painel de Notas – JTabbedPane com aba de lançamento e aba de consulta.
 */
public class NotaPanel extends JPanel {

    private final NotaDAO       notaDAO       = new NotaDAO();
    private final AlunoDAO      alunoDAO      = new AlunoDAO();
    private final DisciplinaDAO disciplinaDAO = new DisciplinaDAO();

    // ── Aba Lançamento ────────────────────────────────────────────────────
    private JComboBox<Aluno>       cbAluno;
    private JComboBox<Disciplina>  cbDisc;
    private JTextField             tfSemestre;
    private JTextField             tfAv1, tfAv2, tfAv3, tfAv4, tfNotaFinal;
    private JLabel                 lblMedia;
    private JComboBox<String>      cbSituacao;
    private Nota                   notaEditando;

    // ── Aba Consulta ─────────────────────────────────────────────────────
    private JTable         table;
    private DefaultTableModel tableModel;

    public NotaPanel() {
        setLayout(new BorderLayout());
        setBackground(UITheme.BG_PANEL);
        add(buildHeader(), BorderLayout.NORTH);

        JTabbedPane tp = new JTabbedPane();
        tp.setFont(UITheme.FONT_SUBTITLE);
        tp.addTab("📝  Lançar Notas",  buildLancamentoTab());
        tp.addTab("📊  Consultar",     buildConsultaTab());
        add(tp, BorderLayout.CENTER);

        carregarCombos();
        carregarTabela();
    }

    private JPanel buildHeader() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(new Color(0x2C3E50));
        p.setBorder(BorderFactory.createEmptyBorder(14, 20, 14, 20));
        JLabel lbl = new JLabel("📝  Gerenciamento de Notas");
        lbl.setFont(UITheme.FONT_TITLE);
        lbl.setForeground(Color.WHITE);
        p.add(lbl, BorderLayout.WEST);
        return p;
    }

    // ── Aba Lançamento ────────────────────────────────────────────────────
    private JPanel buildLancamentoTab() {
        JPanel root = new JPanel(new BorderLayout(0, 10));
        root.setBackground(UITheme.BG_PANEL);
        root.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(UITheme.BG_CARD);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER),
                BorderFactory.createEmptyBorder(20, 24, 20, 24)));

        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5,6,5,6);
        g.anchor = GridBagConstraints.WEST;
        g.fill   = GridBagConstraints.HORIZONTAL;

        cbAluno    = new JComboBox<>();
        cbDisc     = new JComboBox<>();
        tfSemestre = new JTextField(8);
        tfSemestre.setText("2024.1");

        row(card, g, "Aluno *",       cbAluno,    0, 0);
        row(card, g, "Disciplina *",  cbDisc,     2, 0);
        row(card, g, "Semestre *",    tfSemestre, 4, 0);

        tfAv1 = numField(); tfAv2 = numField(); tfAv3 = numField(); tfAv4 = numField();
        tfNotaFinal = numField();
        lblMedia = new JLabel("0,00");
        lblMedia.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblMedia.setForeground(UITheme.SECONDARY);

        // atualiza média ao sair de cada campo
        for (JTextField tf : new JTextField[]{tfAv1, tfAv2, tfAv3, tfAv4})
            tf.addFocusListener(new java.awt.event.FocusAdapter() {
                public void focusLost(java.awt.event.FocusEvent e) { recalcMedia(); }
            });

        row(card, g, "AV1",    tfAv1,      0, 1);
        row(card, g, "AV2",    tfAv2,      2, 1);
        row(card, g, "AV3",    tfAv3,      4, 1);
        row(card, g, "AV4",    tfAv4,      0, 2);

        g.gridx=2; g.gridy=5; card.add(new JLabel("Média Calculada:"), g);
        g.gridx=3; card.add(lblMedia, g);

        row(card, g, "Nota Final", tfNotaFinal, 4, 2);

        cbSituacao = new JComboBox<>(new String[]{"Em Andamento","Aprovado","Reprovado"});
        cbSituacao.setFont(UITheme.FONT_BODY);
        row(card, g, "Situação", cbSituacao, 0, 3);

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.CENTER,10,4));
        btns.setOpaque(false);
        StyledButton btnSalvar = StyledButton.success("💾  Salvar");
        StyledButton btnLimpar = StyledButton.primary("🔄  Limpar");
        btnSalvar.addActionListener(e -> salvar());
        btnLimpar.addActionListener(e -> limpar());
        btns.add(btnSalvar); btns.add(btnLimpar);

        JScrollPane sc = new JScrollPane(card);
        sc.setBorder(null); sc.getViewport().setBackground(UITheme.BG_PANEL);
        root.add(sc,   BorderLayout.CENTER);
        root.add(btns, BorderLayout.SOUTH);
        return root;
    }

    private JTextField numField() {
        JTextField tf = new JTextField("0", 6);
        tf.setFont(UITheme.FONT_BODY);
        tf.setHorizontalAlignment(JTextField.CENTER);
        return tf;
    }

    private void row(JPanel p, GridBagConstraints g, String lbl, JComponent c, int col, int row) {
        JLabel l = new JLabel(lbl);
        l.setFont(UITheme.FONT_LABEL);
        g.gridx=col; g.gridy=row*2;   p.add(l, g);
        g.gridx=col; g.gridy=row*2+1; p.add(c, g);
    }

    // ── Aba Consulta ─────────────────────────────────────────────────────
    private JPanel buildConsultaTab() {
        JPanel root = new JPanel(new BorderLayout(0,8));
        root.setBackground(UITheme.BG_PANEL);
        root.setBorder(BorderFactory.createEmptyBorder(12,15,12,15));

        String[] cols = {"ID","RGM","Aluno","Disciplina","Semestre","AV1","AV2","AV3","AV4","Média","Situação"};
        tableModel = new DefaultTableModel(cols,0){
            public boolean isCellEditable(int r,int c){return false;}
        };
        table = new JTable(tableModel);
        estilizarTabela(table);

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT,8,4));
        top.setOpaque(false);
        StyledButton btnAtt    = StyledButton.primary("↻  Atualizar");
        StyledButton btnEditar = StyledButton.warning("✏  Editar");
        StyledButton btnDel    = StyledButton.danger ("🗑  Excluir");
        btnAtt   .addActionListener(e->carregarTabela());
        btnEditar.addActionListener(e->carregarParaEditar());
        btnDel   .addActionListener(e->excluirSelecionado());
        top.add(btnAtt); top.add(btnEditar); top.add(btnDel);

        root.add(top, BorderLayout.NORTH);
        root.add(new JScrollPane(table), BorderLayout.CENTER);
        return root;
    }

    private void estilizarTabela(JTable t) {
        t.setFont(UITheme.FONT_BODY); t.setRowHeight(28);
        t.setGridColor(UITheme.BORDER);
        t.getTableHeader().setFont(UITheme.FONT_LABEL);
        t.getTableHeader().setBackground(UITheme.TABLE_HEADER);
        t.getTableHeader().setForeground(Color.WHITE);
        t.getColumnModel().getColumn(0).setMinWidth(0);
        t.getColumnModel().getColumn(0).setMaxWidth(0);
        t.getColumnModel().getColumn(0).setWidth(0);
    }

    // ── Lógica ───────────────────────────────────────────────────────────
    private void carregarCombos() {
        try {
            cbAluno.removeAllItems();
            for (Aluno a : alunoDAO.listarTodos()) cbAluno.addItem(a);
            cbDisc.removeAllItems();
            for (Disciplina d : disciplinaDAO.listarTodas()) cbDisc.addItem(d);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar dados:\n"+ex.getMessage(),"Erro",JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarTabela() {
        try {
            tableModel.setRowCount(0);
            for (Nota n : notaDAO.listarTodas()) {
                tableModel.addRow(new Object[]{
                    n.getId(), n.getRgm(), n.getNomeAluno(), n.getNomeDisciplina(),
                    n.getSemestre(), n.getAv1(), n.getAv2(), n.getAv3(), n.getAv4(),
                    String.format("%.2f", n.getMedia()), n.getSituacao()
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,"Erro:\n"+ex.getMessage(),"Erro",JOptionPane.ERROR_MESSAGE);
        }
    }

    private void recalcMedia() {
        try {
            double m = (parse(tfAv1)+parse(tfAv2)+parse(tfAv3)+parse(tfAv4)) / 4.0;
            lblMedia.setText(String.format("%.2f", m));
            lblMedia.setForeground(m >= 6.0 ? UITheme.SUCCESS : UITheme.DANGER);
        } catch (Exception ignored) {}
    }

    private double parse(JTextField tf) {
        try { return Double.parseDouble(tf.getText().replace(",",".")); }
        catch(NumberFormatException e) { return 0; }
    }

    private void salvar() {
        Aluno a = (Aluno) cbAluno.getSelectedItem();
        Disciplina d = (Disciplina) cbDisc.getSelectedItem();
        if (a==null||d==null||tfSemestre.getText().isBlank()) {
            JOptionPane.showMessageDialog(this,"Preencha aluno, disciplina e semestre.","Atenção",JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            if (notaEditando==null) {
                Nota exist = notaDAO.buscarPorAlunoDiscSemestre(a.getId(), d.getId(), tfSemestre.getText().trim());
                if (exist!=null) {
                    JOptionPane.showMessageDialog(this,"Já existe nota para este aluno/disciplina/semestre.","Atenção",JOptionPane.WARNING_MESSAGE);
                    return;
                }
                notaEditando = new Nota();
                notaEditando.setAlunoId(a.getId());
                notaEditando.setDisciplinaId(d.getId());
                notaEditando.setSemestre(tfSemestre.getText().trim());
            }
            notaEditando.setAv1(parse(tfAv1)); notaEditando.setAv2(parse(tfAv2));
            notaEditando.setAv3(parse(tfAv3)); notaEditando.setAv4(parse(tfAv4));
            notaEditando.setNotaFinal(parse(tfNotaFinal));
            notaEditando.setSituacao((String) cbSituacao.getSelectedItem());
            notaDAO.salvar(notaEditando);
            JOptionPane.showMessageDialog(this,"Nota salva!","Sucesso",JOptionPane.INFORMATION_MESSAGE);
            limpar(); carregarTabela();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,"Erro:\n"+ex.getMessage(),"Erro",JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarParaEditar() {
        int row = table.getSelectedRow();
        if (row<0){JOptionPane.showMessageDialog(this,"Selecione uma nota.");return;}
        notaEditando = new Nota();
        notaEditando.setId((int)tableModel.getValueAt(row,0));
        tfAv1.setText(tableModel.getValueAt(row,5).toString());
        tfAv2.setText(tableModel.getValueAt(row,6).toString());
        tfAv3.setText(tableModel.getValueAt(row,7).toString());
        tfAv4.setText(tableModel.getValueAt(row,8).toString());
        cbSituacao.setSelectedItem(tableModel.getValueAt(row,10));
        recalcMedia();
    }

    private void excluirSelecionado() {
        int row = table.getSelectedRow();
        if (row<0){JOptionPane.showMessageDialog(this,"Selecione uma nota.");return;}
        if (JOptionPane.showConfirmDialog(this,"Excluir esta nota?","Confirmar",
                JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION) {
            try {
                notaDAO.excluir((int)tableModel.getValueAt(row,0));
                carregarTabela();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this,"Erro:\n"+ex.getMessage(),"Erro",JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void limpar() {
        notaEditando=null;
        tfAv1.setText("0"); tfAv2.setText("0"); tfAv3.setText("0"); tfAv4.setText("0");
        tfNotaFinal.setText("0"); lblMedia.setText("0,00");
        cbSituacao.setSelectedIndex(0);
    }
}
