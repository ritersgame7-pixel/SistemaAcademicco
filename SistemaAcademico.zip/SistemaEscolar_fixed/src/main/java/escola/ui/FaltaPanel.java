package escola.ui;

import escola.dao.*;
import escola.model.*;
import escola.util.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

/**
 * Painel de Faltas com JTabbedPane (Lançar / Consultar).
 */
public class FaltaPanel extends JPanel {

    private final FaltaDAO      faltaDAO      = new FaltaDAO();
    private final AlunoDAO      alunoDAO      = new AlunoDAO();
    private final DisciplinaDAO disciplinaDAO = new DisciplinaDAO();

    private JComboBox<Aluno>      cbAluno;
    private JComboBox<Disciplina> cbDisc;
    private JTextField            tfSemestre, tfFaltas, tfTotalAulas;
    private JLabel                lblFreq;
    private Falta                 faltaEditando;

    private JTable            table;
    private DefaultTableModel tableModel;

    public FaltaPanel() {
        setLayout(new BorderLayout());
        setBackground(UITheme.BG_PANEL);
        add(buildHeader(), BorderLayout.NORTH);

        JTabbedPane tp = new JTabbedPane();
        tp.setFont(UITheme.FONT_SUBTITLE);
        tp.addTab("📋  Lançar Faltas", buildLancamentoTab());
        tp.addTab("📊  Consultar",     buildConsultaTab());
        add(tp, BorderLayout.CENTER);

        carregarCombos();
        carregarTabela();
    }

    private JPanel buildHeader() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(new Color(0x6C3483));
        p.setBorder(BorderFactory.createEmptyBorder(14,20,14,20));
        JLabel l = new JLabel("📋  Controle de Faltas");
        l.setFont(UITheme.FONT_TITLE); l.setForeground(Color.WHITE);
        p.add(l, BorderLayout.WEST);
        return p;
    }

    private JPanel buildLancamentoTab() {
        JPanel root = new JPanel(new BorderLayout(0,10));
        root.setBackground(UITheme.BG_PANEL);
        root.setBorder(BorderFactory.createEmptyBorder(15,15,15,15));

        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(UITheme.BG_CARD);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER),
                BorderFactory.createEmptyBorder(20,24,20,24)));

        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5,6,5,6); g.anchor = GridBagConstraints.WEST;
        g.fill   = GridBagConstraints.HORIZONTAL;

        cbAluno    = new JComboBox<>();
        cbDisc     = new JComboBox<>();
        tfSemestre = new JTextField("2024.1", 8);
        tfFaltas   = new JTextField("0", 6); tfFaltas.setHorizontalAlignment(JTextField.CENTER);
        tfTotalAulas = new JTextField("60",6); tfTotalAulas.setHorizontalAlignment(JTextField.CENTER);
        lblFreq    = new JLabel("100%");
        lblFreq.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblFreq.setForeground(UITheme.SUCCESS);

        // recalcula frequência em tempo real
        for (JTextField tf : new JTextField[]{tfFaltas, tfTotalAulas})
            tf.addFocusListener(new java.awt.event.FocusAdapter(){
                public void focusLost(java.awt.event.FocusEvent e){recalcFreq();}
            });

        row(card,g,"Aluno *",       cbAluno,     0,0);
        row(card,g,"Disciplina *",  cbDisc,      2,0);
        row(card,g,"Semestre *",    tfSemestre,  4,0);
        row(card,g,"Total Faltas",  tfFaltas,    0,1);
        row(card,g,"Total de Aulas",tfTotalAulas,2,1);

        g.gridx=4; g.gridy=3; card.add(new JLabel("Frequência:"),g);
        g.gridx=4; g.gridy=4; card.add(lblFreq,g);

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.CENTER,10,4));
        btns.setOpaque(false);
        StyledButton bs = StyledButton.success("💾  Salvar");
        StyledButton bl = StyledButton.primary("🔄  Limpar");
        bs.addActionListener(e->salvar());
        bl.addActionListener(e->limpar());
        btns.add(bs); btns.add(bl);

        JScrollPane sc = new JScrollPane(card);
        sc.setBorder(null); sc.getViewport().setBackground(UITheme.BG_PANEL);
        root.add(sc,   BorderLayout.CENTER);
        root.add(btns, BorderLayout.SOUTH);
        return root;
    }

    private void row(JPanel p, GridBagConstraints g, String lbl, JComponent c, int col, int row){
        JLabel l = new JLabel(lbl); l.setFont(UITheme.FONT_LABEL);
        g.gridx=col; g.gridy=row*2;   p.add(l,g);
        g.gridx=col; g.gridy=row*2+1; p.add(c,g);
    }

    private JPanel buildConsultaTab() {
        JPanel root = new JPanel(new BorderLayout(0,8));
        root.setBackground(UITheme.BG_PANEL);
        root.setBorder(BorderFactory.createEmptyBorder(12,15,12,15));

        String[] cols = {"ID","RGM","Aluno","Disciplina","Semestre","Faltas","Total Aulas","Frequência (%)"};
        tableModel = new DefaultTableModel(cols,0){
            public boolean isCellEditable(int r,int c){return false;}
        };
        table = new JTable(tableModel);
        table.setFont(UITheme.FONT_BODY); table.setRowHeight(28);
        table.getTableHeader().setFont(UITheme.FONT_LABEL);
        table.getTableHeader().setBackground(UITheme.TABLE_HEADER);
        table.getTableHeader().setForeground(Color.WHITE);
        table.getColumnModel().getColumn(0).setMinWidth(0);
        table.getColumnModel().getColumn(0).setMaxWidth(0);
        table.getColumnModel().getColumn(0).setWidth(0);

        // colorir frequência < 75%
        table.getColumnModel().getColumn(7).setCellRenderer(new DefaultTableCellRenderer(){
            public Component getTableCellRendererComponent(JTable t, Object val, boolean isSel,
                    boolean hasFocus, int row, int col){
                super.getTableCellRendererComponent(t,val,isSel,hasFocus,row,col);
                try {
                    double v = Double.parseDouble(val.toString().replace(",",".").replace("%",""));
                    setForeground(v < 75 ? UITheme.DANGER : UITheme.SUCCESS);
                    setFont(UITheme.FONT_LABEL);
                } catch(Exception ignored){}
                return this;
            }
        });

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT,8,4));
        top.setOpaque(false);
        StyledButton btnAtt = StyledButton.primary("↻  Atualizar");
        StyledButton btnEd  = StyledButton.warning("✏  Editar");
        StyledButton btnDel = StyledButton.danger ("🗑  Excluir");
        btnAtt.addActionListener(e->carregarTabela());
        btnEd .addActionListener(e->carregarParaEditar());
        btnDel.addActionListener(e->excluir());
        top.add(btnAtt); top.add(btnEd); top.add(btnDel);

        root.add(top, BorderLayout.NORTH);
        root.add(new JScrollPane(table), BorderLayout.CENTER);
        return root;
    }

    private void carregarCombos(){
        try {
            cbAluno.removeAllItems(); cbDisc.removeAllItems();
            for (Aluno a : alunoDAO.listarTodos()) cbAluno.addItem(a);
            for (Disciplina d : disciplinaDAO.listarTodas()) cbDisc.addItem(d);
        } catch(SQLException ex){
            JOptionPane.showMessageDialog(this,"Erro:\n"+ex.getMessage(),"Erro",JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarTabela(){
        try {
            tableModel.setRowCount(0);
            for(Falta f : faltaDAO.listarTodas()){
                tableModel.addRow(new Object[]{
                    f.getId(), f.getRgm(), f.getNomeAluno(), f.getNomeDisciplina(),
                    f.getSemestre(), f.getTotalFaltas(), f.getTotalAulas(),
                    String.format("%.1f%%", f.getPercentualFreq())
                });
            }
        } catch(SQLException ex){
            JOptionPane.showMessageDialog(this,"Erro:\n"+ex.getMessage(),"Erro",JOptionPane.ERROR_MESSAGE);
        }
    }

    private void recalcFreq(){
        try{
            int f = Integer.parseInt(tfFaltas.getText().trim());
            int t = Integer.parseInt(tfTotalAulas.getText().trim());
            double pct = t>0 ? ((t-f)/(double)t)*100 : 0;
            lblFreq.setText(String.format("%.1f%%",pct));
            lblFreq.setForeground(pct<75 ? UITheme.DANGER : UITheme.SUCCESS);
        } catch(Exception ignored){}
    }

    private void salvar(){
        Aluno a = (Aluno) cbAluno.getSelectedItem();
        Disciplina d = (Disciplina) cbDisc.getSelectedItem();
        if(a==null||d==null||tfSemestre.getText().isBlank()){
            JOptionPane.showMessageDialog(this,"Preencha todos os campos obrigatórios.","Atenção",JOptionPane.WARNING_MESSAGE);
            return;
        }
        try{
            if(faltaEditando==null){
                Falta exist = faltaDAO.buscarPorAlunoDiscSemestre(a.getId(),d.getId(),tfSemestre.getText().trim());
                if(exist!=null){
                    JOptionPane.showMessageDialog(this,"Registro já existe. Use Editar.","Atenção",JOptionPane.WARNING_MESSAGE);
                    return;
                }
                faltaEditando = new Falta();
                faltaEditando.setAlunoId(a.getId());
                faltaEditando.setDisciplinaId(d.getId());
                faltaEditando.setSemestre(tfSemestre.getText().trim());
            }
            faltaEditando.setTotalFaltas(Integer.parseInt(tfFaltas.getText().trim()));
            faltaEditando.setTotalAulas(Integer.parseInt(tfTotalAulas.getText().trim()));
            faltaDAO.salvar(faltaEditando);
            JOptionPane.showMessageDialog(this,"Falta salva!","Sucesso",JOptionPane.INFORMATION_MESSAGE);
            limpar(); carregarTabela();
        } catch(SQLException ex){
            JOptionPane.showMessageDialog(this,"Erro:\n"+ex.getMessage(),"Erro",JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarParaEditar(){
        int row=table.getSelectedRow();
        if(row<0){JOptionPane.showMessageDialog(this,"Selecione um registro.");return;}
        faltaEditando = new Falta();
        faltaEditando.setId((int)tableModel.getValueAt(row,0));
        tfFaltas.setText(tableModel.getValueAt(row,5).toString());
        tfTotalAulas.setText(tableModel.getValueAt(row,6).toString());
        recalcFreq();
    }

    private void excluir(){
        int row=table.getSelectedRow();
        if(row<0){JOptionPane.showMessageDialog(this,"Selecione um registro.");return;}
        if(JOptionPane.showConfirmDialog(this,"Excluir?","Confirmar",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION){
            try{
                faltaDAO.excluir((int)tableModel.getValueAt(row,0));
                carregarTabela();
            } catch(SQLException ex){
                JOptionPane.showMessageDialog(this,"Erro:\n"+ex.getMessage(),"Erro",JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void limpar(){
        faltaEditando=null;
        tfFaltas.setText("0"); tfTotalAulas.setText("60");
        lblFreq.setText("100%"); lblFreq.setForeground(UITheme.SUCCESS);
    }
}
