# Sistema Escolar — Gestão Acadêmica
**Java Swing + MySQL**

---

## Estrutura do Projeto

```
SistemaEscolar/
├── pom.xml                          ← Maven build
├── sql/
│   └── escola.sql                   ← Script de criação do banco
└── src/main/java/escola/
    ├── connection/
    │   └── ConnectionFactory.java   ← Singleton de conexão MySQL
    ├── model/
    │   ├── Aluno.java
    │   ├── Disciplina.java
    │   ├── Nota.java
    │   └── Falta.java
    ├── dao/
    │   ├── AlunoDAO.java            ← CRUD + verificação RGM único
    │   ├── DisciplinaDAO.java
    │   ├── NotaDAO.java
    │   └── FaltaDAO.java
    ├── util/
    │   ├── UITheme.java             ← Paleta de cores e fontes
    │   ├── StyledButton.java        ← Botão estilizado com hover
    │   └── FormattedFieldFactory.java ← JFormattedTextField (CPF/Cel/Data)
    └── ui/
        ├── MainFrame.java           ← Janela principal (sidebar + CardLayout)
        ├── AlunoPanel.java          ← Cadastro de alunos (JTabbedPane)
        ├── DisciplinaPanel.java     ← Cadastro de disciplinas
        ├── NotaPanel.java           ← Lançamento de notas
        ├── FaltaPanel.java          ← Controle de faltas
        └── BoletimPanel.java        ← Boletim com impressão
```

---

## Pré-requisitos

| Ferramenta | Versão mínima |
|---|---|
| Java JDK | 17 |
| Maven | 3.8+ |
| MySQL | 8.0+ |

---

## Como executar

### 1. Criar o banco de dados

```bash
mysql -u root -p < sql/escola.sql
```

Ou abra o arquivo `sql/escola.sql` no MySQL Workbench e execute.

### 2. Configurar a conexão (se necessário)

Edite `src/main/java/escola/connection/ConnectionFactory.java`:

```java
private static final String URL  = "jdbc:mysql://localhost:3306/escola_db?...";
private static final String USER = "root";
private static final String PASS = "sua_senha";   // ← altere aqui
```

### 3. Compilar e empacotar

```bash
cd SistemaEscolar
mvn clean package -q
```

### 4. Executar

```bash
java -jar target/sistema-escolar-1.0.0-jar-with-dependencies.jar
```

---

## Funcionalidades

### 🏠 Dashboard
- Cards de acesso rápido para todas as telas
- Regras do sistema (aprovação ≥ 6,0; frequência ≥ 75%)

### 👨‍🎓 Alunos  (`JTabbedPane`)
- **Aba Cadastro**: campos com `JFormattedTextField` para CPF, Celular e Data de Nascimento
- **Aba Listagem**: tabela com busca por nome, botão de editar/excluir
- Validação de **RGM único** (duplicado é bloqueado com mensagem)
- Exclusão em **cascade**: notas e faltas são removidas junto (via FK no BD)
- Status: Ativo / Inativo / Trancado

### 📚 Disciplinas  (`JTabbedPane`)
- CRUD completo com código, nome, carga horária, período e curso

### 📝 Notas  (`JTabbedPane`)
- Lançamento de AV1, AV2, AV3, AV4 + Nota Final
- **Média calculada automaticamente** em tempo real ao sair do campo
- Indicação visual verde/vermelho da média
- Situação: Aprovado / Reprovado / Em Andamento

### 📋 Faltas  (`JTabbedPane`)
- Registro de total de faltas e total de aulas
- **Frequência calculada automaticamente**
- Destaque vermelho quando frequência < 75%

### 📄 Boletim
- Seleção de aluno + semestre
- Card visual com cabeçalho colorido, tabela de notas/frequência
- Indicadores: Média Geral, Disciplinas, Situação Final
- **Impressão** via `java.awt.print`

---

## Banco de Dados

```
alunos ──< notas >── disciplinas
alunos ──< faltas >── disciplinas
```

- `alunos.rgm` → `UNIQUE` (impede duplicidade)
- `notas` → `ON DELETE CASCADE` quando aluno é excluído
- `faltas` → `ON DELETE CASCADE` quando aluno é excluído
- Colunas `media` e `percentual_freq` são `GENERATED ALWAYS` (calculadas pelo MySQL)
