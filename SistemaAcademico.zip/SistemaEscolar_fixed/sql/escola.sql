-- ============================================================
-- SISTEMA ESCOLAR - Script de Criação do Banco de Dados SQLite
-- ============================================================

PRAGMA foreign_keys = ON;

-- ============================================================
-- TABELA: alunos
-- ============================================================
CREATE TABLE IF NOT EXISTS alunos (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    rgm           TEXT    NOT NULL UNIQUE,
    nome          TEXT    NOT NULL,
    cpf           TEXT    NOT NULL,
    celular       TEXT    NOT NULL,
    email         TEXT,
    data_nasc     TEXT    NOT NULL,
    endereco      TEXT,
    curso         TEXT,
    periodo       TEXT,
    status        TEXT    NOT NULL DEFAULT 'Ativo'
                          CHECK (status IN ('Ativo','Inativo','Trancado')),
    data_cadastro TEXT    DEFAULT (datetime('now','localtime'))
);

-- ============================================================
-- TABELA: disciplinas
-- ============================================================
CREATE TABLE IF NOT EXISTS disciplinas (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    codigo     TEXT    NOT NULL UNIQUE,
    nome       TEXT    NOT NULL,
    carga_hora INTEGER NOT NULL DEFAULT 60,
    periodo    TEXT,
    curso      TEXT
);

-- ============================================================
-- TABELA: notas
-- (FK -> alunos e disciplinas; CASCADE DELETE se aluno for excluído)
-- Nota: SQLite não suporta colunas geradas via GENERATED ALWAYS com
-- STORED de forma portável em versões antigas. A média é calculada
-- na camada Java (NotaDAO) e gravada no campo media.
-- ============================================================
CREATE TABLE IF NOT EXISTS notas (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    aluno_id      INTEGER NOT NULL,
    disciplina_id INTEGER NOT NULL,
    semestre      TEXT    NOT NULL,
    nota_av1      REAL    DEFAULT 0.0,
    nota_av2      REAL    DEFAULT 0.0,
    nota_av3      REAL    DEFAULT 0.0,
    nota_av4      REAL    DEFAULT 0.0,
    nota_final    REAL    DEFAULT 0.0,
    media         REAL    DEFAULT 0.0,
    situacao      TEXT    DEFAULT 'Em Andamento'
                          CHECK (situacao IN ('Aprovado','Reprovado','Em Andamento')),
    CONSTRAINT fk_nota_aluno FOREIGN KEY (aluno_id)
        REFERENCES alunos(id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_nota_disc  FOREIGN KEY (disciplina_id)
        REFERENCES disciplinas(id) ON DELETE CASCADE ON UPDATE CASCADE,
    UNIQUE (aluno_id, disciplina_id, semestre)
);

-- ============================================================
-- TABELA: faltas
-- (FK -> alunos e disciplinas; CASCADE DELETE se aluno for excluído)
-- percentual_freq calculado na camada Java (FaltaDAO).
-- ============================================================
CREATE TABLE IF NOT EXISTS faltas (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    aluno_id        INTEGER NOT NULL,
    disciplina_id   INTEGER NOT NULL,
    semestre        TEXT    NOT NULL,
    total_faltas    INTEGER NOT NULL DEFAULT 0,
    total_aulas     INTEGER NOT NULL DEFAULT 60,
    percentual_freq REAL    DEFAULT 0.0,
    CONSTRAINT fk_falta_aluno FOREIGN KEY (aluno_id)
        REFERENCES alunos(id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_falta_disc  FOREIGN KEY (disciplina_id)
        REFERENCES disciplinas(id) ON DELETE CASCADE ON UPDATE CASCADE,
    UNIQUE (aluno_id, disciplina_id, semestre)
);

-- ============================================================
-- DADOS DE EXEMPLO
-- ============================================================

INSERT OR IGNORE INTO disciplinas (codigo, nome, carga_hora, periodo, curso) VALUES
('MAT101', 'Matemática Discreta',          60, '1º', 'Ciência da Computação'),
('PRG101', 'Algoritmos e Programação',     80, '1º', 'Ciência da Computação'),
('BD101',  'Banco de Dados',               60, '2º', 'Ciência da Computação'),
('POO101', 'Programação Orientada a Obj.', 80, '2º', 'Ciência da Computação'),
('RED101', 'Redes de Computadores',        60, '3º', 'Ciência da Computação'),
('SO101',  'Sistemas Operacionais',        60, '3º', 'Ciência da Computação');

INSERT OR IGNORE INTO alunos (rgm, nome, cpf, celular, email, data_nasc, endereco, curso, periodo, status) VALUES
('2024001', 'Ana Paula Silva',     '123.456.789-00', '(11) 91234-5678', 'ana@email.com',   '2002-03-15', 'Rua das Flores, 100', 'Ciência da Computação', '1º', 'Ativo'),
('2024002', 'Bruno Costa Lima',   '987.654.321-00', '(11) 98765-4321', 'bruno@email.com', '2001-07-22', 'Av. Brasil, 200',     'Ciência da Computação', '2º', 'Ativo'),
('2024003', 'Carla Mendes Rocha', '456.789.123-00', '(11) 94567-8912', 'carla@email.com', '2003-11-10', 'Rua Boa Vista, 300',  'Ciência da Computação', '1º', 'Ativo');
